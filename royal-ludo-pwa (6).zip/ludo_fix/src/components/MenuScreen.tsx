import type { T } from '../game/i18n';
import type { HomeStyle } from '../game/styles';
import { CrownIcon, TELEGRAM_URL, WHATSAPP_URL } from './ui';

interface Props {
  t: T;
  homeStyle: HomeStyle;
  canContinue: boolean;
  onPlay: () => void;
  onContinue: () => void;
  onRules: () => void;
  onSettings: () => void;
  onAbout: () => void;
  onStats: () => void;
}

// "Royal Ludo BD" -> the BD part is shown as a small badge.
function Title({ t, split }: { t: T; split?: boolean }) {
  const base = t('appName').replace(/\s*BD$/, '');
  const words = base.split(' ');
  return (
    <h1 className="home-title">
      {split && words.length > 1 ? (
        <>
          {words[0]}
          <br />
          {words.slice(1).join(' ')}
        </>
      ) : (
        base
      )}
      <span className="hm-bd">BD</span>
    </h1>
  );
}

function Credit({ t }: { t: T }) {
  return (
    <footer className="hm-foot">
      <p className="hm-credit">
        {t('devCredit')} ·{' '}
        <a href={TELEGRAM_URL} target="_blank" rel="noopener noreferrer">
          t.me/appdevbyrakib
        </a>
        <br />
        <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer">
          {t('whatsapp')}
        </a>
      </p>
      <p className="hm-noads">{t('noAds')}</p>
    </footer>
  );
}

export function MenuScreen(p: Props) {
  const { t, homeStyle, canContinue } = p;
  const items = [
    { icon: '📜', label: t('rules'), go: p.onRules },
    { icon: '⚙️', label: t('settings'), go: p.onSettings },
    { icon: '📊', label: t('stats'), go: p.onStats },
    { icon: 'ℹ️', label: t('about'), go: p.onAbout },
  ];

  if (homeStyle === 'ivory') {
    return (
      <div className="home home-ivory">
        <div className="hm-col">
          <CrownIcon className="hm-cr" />
          <Title t={t} />
          <div className="hm-rule" />
          <p className="hm-tag">{t('tagline')}</p>
          <div className="hm-list">
            <button type="button" className="hm-row hm-pri" onClick={p.onPlay}>
              <span aria-hidden="true">🎲</span>
              <em>{t('play')}</em>
              <u aria-hidden="true">›</u>
            </button>
            {canContinue && (
              <button type="button" className="hm-row" onClick={p.onContinue}>
                <span aria-hidden="true">▶</span>
                <em>{t('continueGame')}</em>
                <u aria-hidden="true">›</u>
              </button>
            )}
            {items.map((it) => (
              <button key={it.label} type="button" className="hm-row" onClick={it.go}>
                <span aria-hidden="true">{it.icon}</span>
                <em>{it.label}</em>
                <u aria-hidden="true">›</u>
              </button>
            ))}
          </div>
        </div>
        <Credit t={t} />
      </div>
    );
  }

  if (homeStyle === 'neon') {
    return (
      <div className="home home-neon">
        <span className="hm-fl" style={{ left: 18, top: '11%' }} aria-hidden="true">🎲</span>
        <span className="hm-fl" style={{ right: 18, top: '21%', animationDelay: '-1.4s' }} aria-hidden="true">🎯</span>
        <div className="hm-col">
          <Title t={t} split />
          <p className="hm-tag">{t('tagline')}</p>
          <button type="button" className="hm-btn hm-pri" onClick={p.onPlay}>
            🎲 {t('play')}
          </button>
          {canContinue && (
            <button type="button" className="hm-btn" onClick={p.onContinue}>
              ▶ {t('continueGame')}
            </button>
          )}
          <div className="hm-two">
            {items.map((it) => (
              <button key={it.label} type="button" className="hm-btn" onClick={it.go}>
                {it.icon} {it.label}
              </button>
            ))}
          </div>
        </div>
        <Credit t={t} />
      </div>
    );
  }

  // aurora
  return (
    <div className="home home-aurora">
      <div className="hm-col">
        <div className="hm-ico">
          <CrownIcon className="h-full w-full" />
        </div>
        <Title t={t} />
        <p className="hm-tag">{t('tagline')}</p>
        <button type="button" className="hm-btn hm-pri" onClick={p.onPlay}>
          🎲 {t('play')}
        </button>
        {canContinue && (
          <button type="button" className="hm-btn hm-glass" onClick={p.onContinue}>
            ▶ {t('continueGame')}
          </button>
        )}
        <div className="hm-tiles">
          {items.map((it) => (
            <button key={it.label} type="button" className="hm-tile" onClick={it.go}>
              <em aria-hidden="true">{it.icon}</em>
              {it.label}
            </button>
          ))}
        </div>
      </div>
      <Credit t={t} />
    </div>
  );
}
