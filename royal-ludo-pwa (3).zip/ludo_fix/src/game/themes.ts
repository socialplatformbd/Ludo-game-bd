import type { Color } from './logic';

export type ThemeId =
  | 'royal'
  | 'emerald'
  | 'midnight'
  | 'neon'
  | 'wood'
  | 'marble'
  | 'crimson'
  | 'ocean'
  | 'galaxy'
  | 'sunset';

export interface ThemeDef {
  id: ThemeId;
  bgInner: string; // centre colour of the board frame
  bgOuter: string; // edge colour of the board frame
  cell: string; // cream track cells
  cellStroke: string;
  yard: string; // inner colour of home yards
  frame: [string, string, string]; // gradient stops for the frame border
  swatch: string; // CSS background used in the theme picker
  pattern?: 'dots' | 'diamonds' | 'stars'; // fine texture on the board frame
}

export const THEMES: Record<ThemeId, ThemeDef> = {
  royal: {
    id: 'royal',
    bgInner: '#2b4fc0',
    bgOuter: '#0a1a4d',
    cell: '#fcf3dc',
    cellStroke: '#b98a3e',
    yard: '#fff8e6',
    frame: ['#fff1b8', '#d4a017', '#7a4d00'],
    swatch: 'linear-gradient(135deg,#2b4fc0,#0a1a4d 70%,#d4a017)',
  },
  emerald: {
    id: 'emerald',
    bgInner: '#1f7a4d',
    bgOuter: '#03281a',
    cell: '#f7f1dc',
    cellStroke: '#a9802f',
    yard: '#fdf9ea',
    frame: ['#fff1b8', '#d4a017', '#7a4d00'],
    swatch: 'linear-gradient(135deg,#1f7a4d,#03281a 70%,#d4a017)',
  },
  midnight: {
    id: 'midnight',
    bgInner: '#4c2a8a',
    bgOuter: '#0a0716',
    cell: '#f1eee6',
    cellStroke: '#8e97a6',
    yard: '#f8f7f2',
    frame: ['#f5f7fa', '#b8c0cc', '#5b6472'],
    swatch: 'linear-gradient(135deg,#4c2a8a,#0a0716 70%,#c0c8d4)',
  },
  neon: {
    id: 'neon',
    bgInner: '#1b0f4a',
    bgOuter: '#03010d',
    cell: '#1c2146',
    cellStroke: '#22d3ee',
    yard: '#10143a',
    frame: ['#a5f3fc', '#22d3ee', '#0e7490'],
    swatch: 'linear-gradient(135deg,#1b0f4a,#03010d 65%,#22d3ee)',
    pattern: 'diamonds',
  },
  wood: {
    id: 'wood',
    bgInner: '#9a6330',
    bgOuter: '#3a2010',
    cell: '#f6e6c3',
    cellStroke: '#6b4423',
    yard: '#fbefd2',
    frame: ['#f7dca6', '#b8864b', '#5a3a1a'],
    swatch: 'linear-gradient(135deg,#9a6330,#3a2010 70%,#f7dca6)',
  },
  marble: {
    id: 'marble',
    bgInner: '#eceef4',
    bgOuter: '#8f95aa',
    cell: '#fcfcfa',
    cellStroke: '#b3ae9f',
    yard: '#ffffff',
    frame: ['#fff1b8', '#d4a017', '#7a4d00'],
    swatch: 'linear-gradient(135deg,#f6f7fb,#8f95aa 70%,#d4a017)',
    pattern: 'diamonds',
  },
  crimson: {
    id: 'crimson',
    bgInner: '#a3202f',
    bgOuter: '#2a0509',
    cell: '#fbeee3',
    cellStroke: '#b8864b',
    yard: '#fff4ea',
    frame: ['#fff1b8', '#d4a017', '#7a4d00'],
    swatch: 'linear-gradient(135deg,#a3202f,#2a0509 70%,#d4a017)',
    pattern: 'diamonds',
  },
  ocean: {
    id: 'ocean',
    bgInner: '#0f8a94',
    bgOuter: '#021f2b',
    cell: '#effafa',
    cellStroke: '#5fb3b8',
    yard: '#f6fdfd',
    frame: ['#e0fbff', '#7dd3d8', '#1b6b73'],
    swatch: 'linear-gradient(135deg,#0f8a94,#021f2b 70%,#e0fbff)',
    pattern: 'dots',
  },
  galaxy: {
    id: 'galaxy',
    bgInner: '#3f2086',
    bgOuter: '#05020e',
    cell: '#ebe6f7',
    cellStroke: '#8b7bd1',
    yard: '#f5f2fc',
    frame: ['#f0e6ff', '#a78bfa', '#4c1d95'],
    swatch: 'linear-gradient(135deg,#3f2086,#05020e 70%,#a78bfa)',
    pattern: 'stars',
  },
  sunset: {
    id: 'sunset',
    bgInner: '#e8812f',
    bgOuter: '#561808',
    cell: '#fff3dc',
    cellStroke: '#c27a2c',
    yard: '#fff8ea',
    frame: ['#fff1b8', '#e0a52a', '#7a4d00'],
    swatch: 'linear-gradient(135deg,#e8812f,#561808 70%,#fff1b8)',
    pattern: 'dots',
  },
};

export interface Palette {
  main: string;
  dark: string;
  light: string;
  hi: string; // token gloss highlight
  mid: string; // token body
  lo: string; // token shadow edge
}

export const PALETTE: Record<Color, Palette> = {
  red: { main: '#e53e5a', dark: '#9b1c36', light: '#ffd7de', hi: '#ffb3c0', mid: '#e11d48', lo: '#7f1028' },
  green: { main: '#22a35a', dark: '#14532d', light: '#d6f5e1', hi: '#b8f5cf', mid: '#16a34a', lo: '#0b4a25' },
  yellow: { main: '#f5b82e', dark: '#a16207', light: '#fff4c2', hi: '#fff9d6', mid: '#facc15', lo: '#a16207' },
  blue: { main: '#2f6fe0', dark: '#1e3a8a', light: '#d7e5ff', hi: '#b6d2ff', mid: '#2563eb', lo: '#1e3a8a' },
};
