Royal Ludo project (mobile-first)

এই ZIP-এ React + Vite সোর্স কোড রয়েছে। এটি APK নয়।

চালানোর জন্য Node.js/npm-সহ পরিবেশে:
1) ZIP Extract করুন
2) প্রজেক্ট ফোল্ডারে terminal খুলুন
3) npm ci
4) npm run dev

Production build: npm run build

গুরুত্বপূর্ণ:
- এই সংস্করণে local multiplayer এবং CPU gameplay-এর কোড রয়েছে।
- Online multiplayer এবং Android APK packaging এখনও অন্তর্ভুক্ত নয়।
- কোনো API key দরকার নেই; প্রজেক্টে secret API key রাখা হয়নি।
- এই পরিবেশে dependency download সম্পন্ন না হওয়ায় production build চালিয়ে যাচাই করা যায়নি।
