import { Card, Page, SettingRow, Toggle } from './ui';
import type { Key, T } from '../game/i18n';
import type { Rules } from '../game/logic';

interface Props {
  t: T;
  rules: Rules;
  onChange: (patch: Partial<Rules>) => void;
  onBack: () => void;
}

const RULE_TEXT: Key[] = ['rule1', 'rule2', 'rule3', 'rule4', 'rule5', 'rule6', 'rule7'];

const HOUSE_RULES: { key: keyof Rules; label: Key }[] = [
  { key: 'bonusOnSix', label: 'hrBonusSix' },
  { key: 'tripleSix', label: 'hrTripleSix' },
  { key: 'safeSpots', label: 'hrSafe' },
  { key: 'exactFinish', label: 'hrExact' },
  { key: 'captureBonus', label: 'hrCaptureBonus' },
  { key: 'homeBonus', label: 'hrHomeBonus' },
];

export function RulesScreen({ t, rules, onChange, onBack }: Props) {
  return (
    <Page title={t('rulesTitle')} t={t} onBack={onBack}>
      <Card>
        <ol className="flex list-decimal flex-col gap-3 pl-5 text-[15px] leading-relaxed text-amber-50 marker:font-bold marker:text-amber-300">
          {RULE_TEXT.map((k) => (
            <li key={k}>{t(k)}</li>
          ))}
        </ol>
      </Card>

      <Card>
        <p className="text-xs font-semibold uppercase tracking-widest text-amber-200/85">{t('houseRules')}</p>
        <p className="mb-2 mt-1 text-xs text-amber-100/70">{t('houseHint')}</p>
        {HOUSE_RULES.map((rule) => (
          <SettingRow key={rule.key} label={t(rule.label)}>
            <Toggle
              label={t(rule.label)}
              checked={rules[rule.key]}
              onChange={(v) => onChange({ [rule.key]: v } as Partial<Rules>)}
            />
          </SettingRow>
        ))}
      </Card>
    </Page>
  );
}
