import { useEffect, useState } from 'react';

// Pip positions (percent of a face).
const PIPS: Record<number, [number, number][]> = {
  1: [[50, 50]],
  2: [[27, 27], [73, 73]],
  3: [[27, 27], [50, 50], [73, 73]],
  4: [[27, 27], [73, 27], [27, 73], [73, 73]],
  5: [[27, 27], [73, 27], [50, 50], [27, 73], [73, 73]],
  6: [[27, 25], [73, 25], [27, 50], [73, 50], [27, 75], [73, 75]],
};

// Cube rotation (degrees about X and Y) that brings each face to the front.
const FACE_ANGLE: Record<number, [number, number]> = {
  1: [0, 0],
  2: [0, -90],
  3: [-90, 0],
  4: [90, 0],
  5: [0, 90],
  6: [0, 180],
};

interface Props {
  value: number | null;
  rolling: boolean;
  small?: boolean;
}

// A real 3D cube: it tumbles while rolling, then settles on the rolled face.
export function Dice({ value, rolling, small = false }: Props) {
  const [rot, setRot] = useState({ x: 0, y: 0 });
  const [ms, setMs] = useState(300);

  useEffect(() => {
    if (!rolling) return;
    setMs(90);
    const id = window.setInterval(() => {
      setRot((r) => ({
        x: r.x + 180 + Math.floor(Math.random() * 3) * 90,
        y: r.y + 180 + Math.floor(Math.random() * 3) * 90,
      }));
    }, 90);
    return () => window.clearInterval(id);
  }, [rolling]);

  useEffect(() => {
    if (rolling || value === null) return;
    const [tx, ty] = FACE_ANGLE[value];
    setMs(300);
    setRot((r) => ({
      x: Math.ceil((r.x - tx) / 360) * 360 + tx + 360,
      y: Math.ceil((r.y - ty) / 360) * 360 + ty,
    }));
  }, [value, rolling]);

  const idle = value === null && !rolling;

  return (
    <div
      className={`dice-wrap ${small ? 'dice-sm' : ''} ${idle ? 'opacity-60' : ''}`}
      role="img"
      aria-label={value === null ? 'Dice' : `Dice showing ${value}`}
    >
      <div className="dice-tilt">
        <div
          className="dice-cube"
          style={{
            transform: `rotateX(${rot.x}deg) rotateY(${rot.y}deg)`,
            transition: `transform ${ms}ms ${rolling ? 'linear' : 'cubic-bezier(0.2, 0.9, 0.3, 1.2)'}`,
          }}
        >
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div key={n} className={`dice-face f${n}`}>
              {PIPS[n].map(([x, y], i) => (
                <span
                  key={i}
                  className={`pip ${n === 1 ? 'pip-red' : ''}`}
                  style={{ left: `${x}%`, top: `${y}%` }}
                />
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
