import { COLORS } from '../game/logic';
import { PALETTE } from '../game/themes';
import type { T } from '../game/i18n';
import { CrownIcon } from './ui';

// Short opening animation. Tap anywhere to skip.
export function Splash({ t, onDone }: { t: T; onDone: () => void }) {
  return (
    <div
      className="splash fixed inset-0 z-[60] flex flex-col items-center justify-center gap-6"
      onClick={onDone}
      role="presentation"
    >
      <div className="splash-crown crown-badge">
        <CrownIcon className="h-12 w-16 drop-shadow-lg" />
      </div>
      <h1 className="font-display gold-text splash-title text-5xl font-black tracking-wide">{t('appName')}</h1>
      <div className="flex gap-3" aria-hidden="true">
        {COLORS.map((c, i) => (
          <span
            key={c}
            className="splash-dot h-5 w-5 rounded-full border-2 border-white/80"
            style={{
              animationDelay: `${i * 120}ms`,
              background: `radial-gradient(circle at 35% 30%, ${PALETTE[c].hi}, ${PALETTE[c].mid} 55%, ${PALETTE[c].lo})`,
            }}
          />
        ))}
      </div>
      <p className="text-xs uppercase tracking-[0.3em] text-amber-200/85">{t('tagline')}</p>
    </div>
  );
}
