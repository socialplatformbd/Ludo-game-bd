import { COLORS, type Color } from '../game/logic';
import { PALETTE } from '../game/themes';
import type { TokenStyle } from '../game/tokens';

function starPoints(outer: number, inner: number): string {
  return Array.from({ length: 10 }, (_, i) => {
    const r = i % 2 === 0 ? outer : inner;
    const a = -Math.PI / 2 + (i * Math.PI) / 5;
    return `${(r * Math.cos(a)).toFixed(3)},${(r * Math.sin(a)).toFixed(3)}`;
  }).join(' ');
}

const COIN_STAR = starPoints(0.14, 0.06);
const SPARKLE = 'M0 -0.07 L0.018 -0.018 L0.07 0 L0.018 0.018 L0 0.07 L-0.018 0.018 L-0.07 0 L-0.018 -0.018 Z';

/** Gradients shared by every token design. Put once inside an <svg><defs>. */
export function TokenDefs() {
  return (
    <>
      <linearGradient id="tokGold" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor="#fff1b8" />
        <stop offset="0.5" stopColor="#d4a017" />
        <stop offset="1" stopColor="#7a4d00" />
      </linearGradient>
      {COLORS.map((c) => (
        <g key={c}>
          <radialGradient id={`tok-${c}`} cx="35%" cy="30%" r="75%">
            <stop offset="0" stopColor={PALETTE[c].hi} />
            <stop offset="0.55" stopColor={PALETTE[c].mid} />
            <stop offset="1" stopColor={PALETTE[c].lo} />
          </radialGradient>
          <linearGradient id={`tokBody-${c}`} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor={PALETTE[c].lo} />
            <stop offset="0.28" stopColor={PALETTE[c].hi} />
            <stop offset="0.6" stopColor={PALETTE[c].mid} />
            <stop offset="1" stopColor={PALETTE[c].lo} />
          </linearGradient>
        </g>
      ))}
    </>
  );
}

/** One token, drawn around (0,0) inside a 1 x 1 cell. */
export function TokenShape({ kind, color }: { kind: TokenStyle; color: Color }) {
  const p = PALETTE[color];
  const orb = `url(#tok-${color})`;
  const body = `url(#tokBody-${color})`;

  switch (kind) {
    case 'flat':
      return (
        <>
          <circle r={0.34} fill={p.main} stroke="#ffffff" strokeWidth={0.06} />
          <circle r={0.16} fill={p.dark} opacity={0.35} />
        </>
      );

    case 'ring':
      return (
        <>
          <circle r={0.35} fill={p.main} stroke="#ffffff" strokeWidth={0.05} />
          <circle r={0.17} fill={p.light} stroke={p.dark} strokeWidth={0.04} />
        </>
      );

    case 'pawn':
      return (
        <>
          <ellipse cy={0.2} rx={0.33} ry={0.12} fill={body} stroke="#fff4c2" strokeWidth={0.03} />
          <path d="M-0.25 0.2 C-0.2 0.08 -0.12 0 -0.09 -0.1 L0.09 -0.1 C0.12 0 0.2 0.08 0.25 0.2 Z" fill={body} />
          <ellipse cy={-0.1} rx={0.145} ry={0.045} fill="url(#tokGold)" stroke="#7a4d00" strokeWidth={0.015} />
          <circle cy={-0.22} r={0.17} fill={orb} stroke="#fff4c2" strokeWidth={0.03} />
          <ellipse cx={-0.06} cy={-0.28} rx={0.06} ry={0.035} fill="#ffffff" opacity={0.85} transform="rotate(-30 -0.06 -0.28)" />
          <ellipse cx={-0.12} cy={0.2} rx={0.07} ry={0.025} fill="#ffffff" opacity={0.35} />
        </>
      );

    case 'gem':
      return (
        <g strokeLinejoin="round" stroke="#ffffff" strokeWidth={0.022}>
          <polygon points="-0.3,-0.1 -0.18,-0.3 -0.12,-0.1" fill={p.mid} />
          <polygon points="0.3,-0.1 0.18,-0.3 0.12,-0.1" fill={p.lo} />
          <polygon points="-0.18,-0.3 0.18,-0.3 0.12,-0.1 -0.12,-0.1" fill={p.hi} />
          <polygon points="-0.3,-0.1 -0.12,-0.1 0,0.33" fill={p.mid} />
          <polygon points="-0.12,-0.1 0.12,-0.1 0,0.33" fill={p.main} />
          <polygon points="0.12,-0.1 0.3,-0.1 0,0.33" fill={p.lo} />
          <path d={SPARKLE} transform="translate(-0.1 -0.22)" fill="#ffffff" stroke="none" />
        </g>
      );

    case 'coin':
      return (
        <>
          <circle r={0.36} fill="url(#tokGold)" stroke="#5c3a00" strokeWidth={0.03} />
          <circle r={0.27} fill={orb} stroke="#fff1b8" strokeWidth={0.03} />
          <polygon points={COIN_STAR} fill="#fff1b8" stroke="#7a4d00" strokeWidth={0.02} />
        </>
      );

    case 'crown':
      return (
        <>
          <ellipse cy={0.22} rx={0.3} ry={0.1} fill={body} stroke="#fff4c2" strokeWidth={0.03} />
          <path
            d="M-0.22 0.18 L-0.27 -0.16 L-0.1 -0.04 L0 -0.28 L0.1 -0.04 L0.27 -0.16 L0.22 0.18 Z"
            fill="url(#tokGold)"
            stroke="#5c3a00"
            strokeWidth={0.025}
            strokeLinejoin="round"
          />
          <rect x={-0.22} y={0.04} width={0.44} height={0.12} fill={body} stroke="#5c3a00" strokeWidth={0.015} />
          <circle cx={-0.27} cy={-0.18} r={0.04} fill={p.hi} stroke="#5c3a00" strokeWidth={0.012} />
          <circle cx={0} cy={-0.3} r={0.045} fill={p.hi} stroke="#5c3a00" strokeWidth={0.012} />
          <circle cx={0.27} cy={-0.18} r={0.04} fill={p.hi} stroke="#5c3a00" strokeWidth={0.012} />
        </>
      );

    case 'orb':
      return (
        <>
          <circle r={0.37} fill="url(#tokGold)" />
          <circle r={0.31} fill={orb} />
          <circle r={0.2} fill="none" stroke="#ffffff" strokeWidth={0.025} opacity={0.35} />
          <path d="M-0.2 -0.12 A0.24 0.24 0 0 1 0.02 -0.26" fill="none" stroke="#ffffff" strokeWidth={0.05} strokeLinecap="round" opacity={0.85} />
          <circle cx={0.12} cy={0.14} r={0.035} fill="#ffffff" opacity={0.6} />
        </>
      );

    case 'classic':
    default:
      return (
        <>
          <circle r={0.36} fill={orb} stroke="#fffbea" strokeWidth={0.045} />
          <ellipse cx={-0.1} cy={-0.14} rx={0.13} ry={0.075} fill="#ffffff" opacity={0.75} transform="rotate(-25)" />
        </>
      );
  }
}

/** Small red + blue sample used in the settings picker. */
export function TokenPreview({ kind }: { kind: TokenStyle }) {
  return (
    <svg viewBox="-1 -0.5 2 0.9" className="h-10 w-full" aria-hidden="true">
      <g transform="translate(-0.5 0)">
        <TokenShape kind={kind} color="red" />
      </g>
      <g transform="translate(0.5 0)">
        <TokenShape kind={kind} color="blue" />
      </g>
    </svg>
  );
}
