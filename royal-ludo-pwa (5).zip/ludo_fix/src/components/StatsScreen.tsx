import type { Key, T } from '../game/i18n';
import type { Stats } from '../game/storage';
import { Card, Page } from './ui';

interface Props {
  t: T;
  stats: Stats;
  onBack: () => void;
}

interface Badge {
  icon: string;
  name: Key;
  desc: Key;
  done: (s: Stats) => boolean;
}

const BADGES: Badge[] = [
  { icon: '🏆', name: 'bFirstWin', desc: 'bFirstWinD', done: (s) => s.wins >= 1 },
  { icon: '⚔️', name: 'bHunter', desc: 'bHunterD', done: (s) => s.captures >= 10 },
  { icon: '🎲', name: 'bLucky', desc: 'bLuckyD', done: (s) => s.sixes >= 25 },
  { icon: '🎖️', name: 'bVeteran', desc: 'bVeteranD', done: (s) => s.games >= 10 },
  { icon: '👑', name: 'bChampion', desc: 'bChampionD', done: (s) => s.wins >= 10 },
];

export function StatsScreen({ t, stats, onBack }: Props) {
  const numbers: { key: Key; value: number }[] = [
    { key: 'statGames', value: stats.games },
    { key: 'statWins', value: stats.wins },
    { key: 'statCaptures', value: stats.captures },
    { key: 'statSixes', value: stats.sixes },
  ];

  return (
    <Page title={t('stats')} t={t} onBack={onBack}>
      <div className="grid grid-cols-2 gap-3">
        {numbers.map((n) => (
          <Card key={n.key} className="text-center">
            <div className="font-display gold-text text-4xl font-black">{n.value}</div>
            <div className="mt-1 text-xs font-semibold uppercase tracking-widest text-amber-200/85">{t(n.key)}</div>
          </Card>
        ))}
      </div>

      <Card>
        <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-amber-200/85">{t('badges')}</p>
        <ul className="flex flex-col gap-2">
          {BADGES.map((b) => {
            const done = b.done(stats);
            return (
              <li
                key={b.name}
                className={`flex items-center gap-3 rounded-2xl px-3 py-2 ${done ? 'bg-amber-300/15' : 'bg-white/5 opacity-55'}`}
              >
                <span className={`text-2xl ${done ? '' : 'grayscale'}`} aria-hidden="true">
                  {b.icon}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-bold text-amber-50">{t(b.name)}</div>
                  <div className="text-xs text-amber-100/70">{t(b.desc)}</div>
                </div>
                {done && <span className="text-lg text-amber-300" aria-hidden="true">✓</span>}
              </li>
            );
          })}
        </ul>
      </Card>

      <p className="px-1 text-center text-xs text-amber-100/60">{t('statsHint')}</p>
    </Page>
  );
}
