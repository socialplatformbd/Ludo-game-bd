import { useState } from 'react';
import { seatColors, type Level, type SeatInit } from '../game/logic';
import { colorName, type Key, type T } from '../game/i18n';
import { PALETTE } from '../game/themes';
import { Button, Card, Page } from './ui';

interface Props {
  t: T;
  profileName: string;
  profileAvatar: string;
  onStart: (seats: SeatInit[], level: Level) => void;
  onBack: () => void;
}

const COUNTS = [2, 3, 4];
export const AVATARS = ['😎', '🦁', '🐯', '🦅', '🐼', '🦊', '🐲', '👑', '🔥', '⭐', '🚀', '🎯', '🤖'];
const LEVELS: { id: Level; key: Key }[] = [
  { id: 'easy', key: 'levelEasy' },
  { id: 'normal', key: 'levelNormal' },
  { id: 'hard', key: 'levelHard' },
];

export function SetupScreen({ t, profileName, profileAvatar, onStart, onBack }: Props) {
  const [count, setCount] = useState(2);
  // Default: seat 1 is the human, the rest are computers. Change any seat to human for local play.
  const [cpu, setCpu] = useState<boolean[]>([false, true, true, true]);
  const [names, setNames] = useState<string[]>([profileName, '', '', '']);
  const [avatars, setAvatars] = useState<string[]>([profileAvatar, '🤖', '🤖', '🤖']);
  const [level, setLevel] = useState<Level>('normal');
  const colors = seatColors(count);

  const cycleAvatar = (i: number) =>
    setAvatars((prev) =>
      prev.map((a, j) => (j === i ? AVATARS[(Math.max(0, AVATARS.indexOf(a)) + 1) % AVATARS.length] : a))
    );

  return (
    <Page title={t('newMatch')} t={t} onBack={onBack}>
      <Card>
        <p className="mb-3 text-sm font-semibold uppercase tracking-widest text-amber-200/90">{t('players')}</p>
        <div className="grid grid-cols-3 gap-2">
          {COUNTS.map((n) => (
            <button
              key={n}
              type="button"
              aria-pressed={count === n}
              onClick={() => setCount(n)}
              className={`min-h-14 rounded-2xl text-2xl font-black transition ${
                count === n ? 'btn-gold' : 'btn-ghost'
              }`}
            >
              {n}
            </button>
          ))}
        </div>
      </Card>

      <Card>
        <div className="flex flex-col gap-3">
          {Array.from({ length: count }, (_, i) => {
            const color = colors[i];
            const isCpu = cpu[i];
            const pal = PALETTE[color];
            return (
              <div key={i} className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => cycleAvatar(i)}
                  aria-label={`${colorName(color, t)} avatar`}
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border-2 border-white/80 text-xl shadow transition active:scale-95"
                  style={{ background: `radial-gradient(circle at 35% 30%, ${pal.hi}, ${pal.mid} 60%, ${pal.lo})` }}
                >
                  {avatars[i]}
                </button>
                <input
                  type="text"
                  value={names[i]}
                  maxLength={12}
                  placeholder={`${t('nameLabel')} · ${colorName(color, t)}`}
                  onChange={(e) => setNames((prev) => prev.map((v, j) => (j === i ? e.target.value : v)))}
                  className="h-11 min-w-0 flex-1 rounded-xl border border-amber-300/30 bg-white/5 px-3 text-[15px] text-amber-50 outline-none placeholder:text-amber-100/40 focus:border-amber-300"
                  style={{ userSelect: 'text' }}
                />
                <button
                  type="button"
                  onClick={() => setCpu((prev) => prev.map((v, j) => (j === i ? !v : v)))}
                  aria-pressed={isCpu}
                  className={`h-11 w-[92px] shrink-0 rounded-xl text-xs font-bold transition active:scale-95 ${
                    isCpu ? 'btn-ghost' : 'btn-gold'
                  }`}
                >
                  {isCpu ? `🤖 ${t('computer')}` : `👤 ${t('human')}`}
                </button>
              </div>
            );
          })}
        </div>
      </Card>

      <Card>
        <p className="mb-3 text-sm font-semibold uppercase tracking-widest text-amber-200/90">{t('level')}</p>
        <div className="grid grid-cols-3 gap-2">
          {LEVELS.map((l) => (
            <button
              key={l.id}
              type="button"
              aria-pressed={level === l.id}
              onClick={() => setLevel(l.id)}
              className={`min-h-12 rounded-2xl text-base font-bold transition ${level === l.id ? 'btn-gold' : 'btn-ghost'}`}
            >
              {t(l.key)}
            </button>
          ))}
        </div>
      </Card>

      <p className="px-1 text-center text-sm text-amber-100/70">{t('setupHint')}</p>

      <Button
        className="mt-2 w-full text-lg"
        onClick={() =>
          onStart(
            Array.from({ length: count }, (_, i) => ({
              cpu: cpu[i],
              avatar: avatars[i],
              ...(names[i].trim() ? { name: names[i].trim() } : {}),
            })),
            level
          )
        }
      >
        {t('startGame')}
      </Button>
    </Page>
  );
}
