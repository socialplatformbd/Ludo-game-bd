import type { Key } from './i18n';

export type TokenStyle = 'classic' | 'flat' | 'ring' | 'pawn' | 'gem' | 'coin' | 'crown' | 'orb';

export interface TokenStyleDef {
  id: TokenStyle;
  tier: 'normal' | 'premium';
  name: Key;
}

export const TOKEN_STYLES: TokenStyleDef[] = [
  { id: 'classic', tier: 'normal', name: 'tokClassic' },
  { id: 'flat', tier: 'normal', name: 'tokFlat' },
  { id: 'ring', tier: 'normal', name: 'tokRing' },
  { id: 'pawn', tier: 'premium', name: 'tokPawn' },
  { id: 'gem', tier: 'premium', name: 'tokGem' },
  { id: 'coin', tier: 'premium', name: 'tokCoin' },
  { id: 'crown', tier: 'premium', name: 'tokCrown' },
  { id: 'orb', tier: 'premium', name: 'tokOrb' },
];

export const TOKEN_STYLE_IDS: TokenStyle[] = TOKEN_STYLES.map((s) => s.id);
