// Pure Ludo rules engine. No React and no DOM access here, so the rules are
// easy to read, test, and reuse later (for example on a server in Phase 6).
//
// Coordinates: every cell is [column, row] on a 15 x 15 grid (0..14).
//
// Token "progress" meaning:
//   0        = in the home yard (base)
//   1..51    = on the shared 52-cell track, counted from the player's start cell
//   52..56   = in the player's private home lane
//   57       = finished (in the centre)

export type Color = 'red' | 'green' | 'yellow' | 'blue';
export type Cell = readonly [number, number];

export const COLORS: Color[] = ['red', 'green', 'yellow', 'blue'];
export const HOME = 57;
const TRACK_LEN = 52;
const CENTER: Cell = [7, 7];

// The 52 shared track cells, in clockwise order.
export const TRACK: Cell[] = [
  [6, 13], [6, 12], [6, 11], [6, 10], [6, 9],
  [5, 8], [4, 8], [3, 8], [2, 8], [1, 8], [0, 8],
  [0, 7],
  [0, 6], [1, 6], [2, 6], [3, 6], [4, 6], [5, 6],
  [6, 5], [6, 4], [6, 3], [6, 2], [6, 1], [6, 0],
  [7, 0],
  [8, 0], [8, 1], [8, 2], [8, 3], [8, 4], [8, 5],
  [9, 6], [10, 6], [11, 6], [12, 6], [13, 6], [14, 6],
  [14, 7],
  [14, 8], [13, 8], [12, 8], [11, 8], [10, 8], [9, 8],
  [8, 9], [8, 10], [8, 11], [8, 12], [8, 13], [8, 14],
  [7, 14],
  [6, 14],
];

// Index (in TRACK) of each colour's first cell.
export const START: Record<Color, number> = { red: 0, green: 13, yellow: 26, blue: 39 };

// Star squares: the four start cells plus the cell 8 steps after each start.
export const SAFE_TRACK: number[] = [0, 8, 13, 21, 26, 34, 39, 47];

// Private home lane (progress 52..56) for each colour.
export const HOME_LANE: Record<Color, Cell[]> = {
  red: [[7, 13], [7, 12], [7, 11], [7, 10], [7, 9]],
  green: [[1, 7], [2, 7], [3, 7], [4, 7], [5, 7]],
  yellow: [[7, 1], [7, 2], [7, 3], [7, 4], [7, 5]],
  blue: [[13, 7], [12, 7], [11, 7], [10, 7], [9, 7]],
};

// The four resting spots inside each home yard (indexed by token id 0..3).
export const BASE_SPOTS: Record<Color, Cell[]> = {
  red: [[1, 10], [4, 10], [1, 13], [4, 13]],
  green: [[1, 1], [4, 1], [1, 4], [4, 4]],
  yellow: [[10, 1], [13, 1], [10, 4], [13, 4]],
  blue: [[10, 10], [13, 10], [10, 13], [13, 13]],
};

export interface Token {
  id: number;
  progress: number;
}

export interface Player {
  color: Color;
  cpu: boolean;
  name?: string; // optional custom name
  avatar?: string; // optional emoji avatar
  tokens: Token[];
}

export type Level = 'easy' | 'normal' | 'hard';

export interface SeatStats {
  sixes: number;
  captures: number;
}

export interface SeatInit {
  cpu: boolean;
  name?: string;
  avatar?: string;
}

export interface Rules {
  bonusOnSix: boolean; // rolling a 6 gives another turn
  tripleSix: boolean; // three 6s in a row forfeit the turn
  safeSpots: boolean; // star squares protect tokens
  exactFinish: boolean; // must roll the exact number to reach the centre
  captureBonus: boolean; // capturing gives another turn
  homeBonus: boolean; // getting a token home gives another turn
}

export const DEFAULT_RULES: Rules = {
  bonusOnSix: true,
  tripleSix: true,
  safeSpots: true,
  exactFinish: true,
  captureBonus: false,
  homeBonus: false,
};

export type Phase = 'roll' | 'rolling' | 'move' | 'moving' | 'over';
export type EventKind =
  | 'start'
  | 'roll'
  | 'value'
  | 'six'
  | 'step'
  | 'land'
  | 'capture'
  | 'home'
  | 'pass'
  | 'triple'
  | 'win';

export interface GameEvent {
  kind: EventKind;
  n: number; // increases on every event so the UI can react once per event
}

export interface Moving {
  seat: number;
  tokenId: number;
  steps: number; // steps still to walk
}

export interface GameState {
  players: Player[];
  current: number;
  phase: Phase;
  dice: number | null;
  sixes: number; // consecutive sixes rolled by the current player
  moving: Moving | null;
  winners: number[]; // seat indexes in finishing order
  rules: Rules;
  level: Level; // computer strength
  stats: SeatStats[]; // per-seat numbers for the end-of-match summary
  evt: GameEvent;
}

export type Action =
  | { type: 'ROLL_START' }
  | { type: 'ROLL_RESULT'; value: number }
  | { type: 'MOVE'; tokenId: number }
  | { type: 'PASS' }
  | { type: 'STEP' }
  | { type: 'SET_RULES'; rules: Rules };

// ---------- helpers ----------

export function seatColors(count: number): Color[] {
  if (count <= 2) return ['red', 'yellow']; // opposite corners
  if (count === 3) return ['red', 'green', 'yellow'];
  return [...COLORS];
}

/** Absolute track index for a progress value, or null if not on the shared track. */
export function absIndex(color: Color, progress: number): number | null {
  if (progress < 1 || progress > 51) return null;
  return (START[color] + progress - 1) % TRACK_LEN;
}

/** Grid cell where a token currently sits. */
export function cellOf(color: Color, progress: number, tokenId: number): Cell {
  if (progress <= 0) return BASE_SPOTS[color][tokenId];
  if (progress <= 51) return TRACK[absIndex(color, progress) as number];
  if (progress <= 56) return HOME_LANE[color][progress - 52];
  return CENTER;
}

/** New progress after moving `dice` steps, or null if the move is illegal. */
export function targetProgress(progress: number, dice: number, rules: Rules): number | null {
  if (progress >= HOME) return null; // already finished
  if (progress === 0) return dice === 6 ? 1 : null; // leaving home needs a six
  const next = progress + dice;
  if (next > HOME) return rules.exactFinish ? null : HOME;
  return next;
}

export function legalTokenIds(player: Player, dice: number, rules: Rules): number[] {
  return player.tokens
    .filter((t) => targetProgress(t.progress, dice, rules) !== null)
    .map((t) => t.id);
}

export function homeCount(player: Player): number {
  return player.tokens.filter((t) => t.progress === HOME).length;
}

function opponentsOn(state: GameState, seat: number, abs: number): number {
  let count = 0;
  state.players.forEach((p, i) => {
    if (i === seat) return;
    p.tokens.forEach((t) => {
      if (absIndex(p.color, t.progress) === abs) count += 1;
    });
  });
  return count;
}

export function createGame(seats: SeatInit[], rules: Rules, level: Level = 'normal'): GameState {
  const colors = seatColors(seats.length);
  return {
    players: seats.map((s, i) => ({
      color: colors[i],
      cpu: s.cpu,
      ...(s.name ? { name: s.name } : {}),
      ...(s.avatar ? { avatar: s.avatar } : {}),
      tokens: [0, 1, 2, 3].map((id) => ({ id, progress: 0 })),
    })),
    current: 0,
    phase: 'roll',
    dice: null,
    sixes: 0,
    moving: null,
    winners: [],
    rules,
    level,
    stats: seats.map(() => ({ sixes: 0, captures: 0 })),
    evt: { kind: 'start', n: 0 },
  };
}

/** How many opponent tokens could hit a token standing on `abs` with their next roll (1..6 steps behind it). */
function dangerAt(state: GameState, seat: number, abs: number): number {
  let n = 0;
  state.players.forEach((p, i) => {
    if (i === seat) return;
    p.tokens.forEach((t) => {
      const a = absIndex(p.color, t.progress);
      if (a === null) return;
      const d = (abs - a + TRACK_LEN) % TRACK_LEN;
      if (d >= 1 && d <= 6) n += 1;
    });
  });
  return n;
}

/**
 * Computer opponent.
 *  easy   : random legal move
 *  normal : prefers finishing, captures, leaving home, star squares
 *  hard   : normal + avoids danger, runs from threats, loves the safe home lane
 */
export function chooseCpuMove(state: GameState): number | null {
  const player = state.players[state.current];
  if (state.dice === null) return null;
  const legal = legalTokenIds(player, state.dice, state.rules);
  if (legal.length === 0) return null;
  if (state.level === 'easy') return legal[Math.floor(Math.random() * legal.length)];
  const hard = state.level === 'hard';

  let best = legal[0];
  let bestScore = -Infinity;
  for (const id of legal) {
    const token = player.tokens.find((t) => t.id === id);
    if (!token) continue;
    const target = targetProgress(token.progress, state.dice, state.rules) as number;
    let score = 0;
    if (target === HOME) score += 100;
    if (token.progress === 0) score += 50;
    const abs = absIndex(player.color, target);
    if (abs !== null) {
      const safe = state.rules.safeSpots && SAFE_TRACK.includes(abs);
      if (safe) score += 15;
      else {
        if (opponentsOn(state, state.current, abs) > 0) score += 80;
        if (hard) score -= 30 * dangerAt(state, state.current, abs);
      }
    }
    if (hard) {
      if (target >= 52 && target < HOME) score += 20;
      const here = absIndex(player.color, token.progress);
      if (here !== null && !(state.rules.safeSpots && SAFE_TRACK.includes(here))) {
        score += 22 * dangerAt(state, state.current, here);
      }
    }
    score += target / 10;
    if (score > bestScore) {
      bestScore = score;
      best = id;
    }
  }
  return best;
}

// ---------- reducer ----------

function bumpStat(stats: SeatStats[], seat: number, key: keyof SeatStats, n: number): SeatStats[] {
  if (n === 0) return stats;
  return stats.map((s, i) => (i === seat ? { ...s, [key]: s[key] + n } : s));
}

function bump(state: GameState, kind: EventKind): GameEvent {
  return { kind, n: state.evt.n + 1 };
}

/** Passes the turn to the next player who has not finished yet. */
function nextTurn(state: GameState, kind: EventKind): GameState {
  const count = state.players.length;
  let seat = state.current;
  for (let i = 1; i <= count; i += 1) {
    const candidate = (state.current + i) % count;
    if (!state.winners.includes(candidate)) {
      seat = candidate;
      break;
    }
  }
  return {
    ...state,
    current: seat,
    phase: 'roll',
    dice: null,
    sixes: 0,
    moving: null,
    evt: bump(state, kind),
  };
}

/** Runs once a token has finished walking: captures, finishing, and turn flow. */
function settle(state: GameState, seat: number, tokenId: number): GameState {
  const { rules } = state;
  const mover = state.players[seat];
  const moved = mover.tokens.find((t) => t.id === tokenId);
  const progress = moved ? moved.progress : 0;
  const abs = absIndex(mover.color, progress);

  let captured = 0;
  let players = state.players;
  if (abs !== null && !(rules.safeSpots && SAFE_TRACK.includes(abs))) {
    players = players.map((pl, i) => {
      if (i === seat) return pl;
      const tokens = pl.tokens.map((t) => {
        if (absIndex(pl.color, t.progress) === abs) {
          captured += 1;
          return { ...t, progress: 0 };
        }
        return t;
      });
      return { ...pl, tokens };
    });
  }

  const finished = progress === HOME;
  const done = players[seat].tokens.every((t) => t.progress === HOME);
  const winners =
    done && !state.winners.includes(seat) ? [...state.winners, seat] : state.winners;
  const extra =
    !done &&
    ((state.dice === 6 && rules.bonusOnSix) ||
      (captured > 0 && rules.captureBonus) ||
      (finished && rules.homeBonus));

  const base: GameState = {
    ...state,
    players,
    winners,
    moving: null,
    phase: 'roll',
    dice: null,
    stats: bumpStat(state.stats, seat, 'captures', captured),
  };

  const remaining = players.map((_, i) => i).filter((i) => !winners.includes(i));
  if (remaining.length <= 1) {
    return {
      ...base,
      winners: remaining.length === 1 ? [...winners, remaining[0]] : winners,
      phase: 'over',
      evt: bump(state, 'win'),
    };
  }

  const kind: EventKind = captured > 0 ? 'capture' : finished ? 'home' : 'land';
  if (extra) {
    // Same player rolls again. sixes is kept so triple-six still works.
    return { ...base, evt: bump(state, kind) };
  }
  return nextTurn(base, kind);
}

export function reducer(state: GameState, action: Action): GameState {
  switch (action.type) {
    case 'ROLL_START': {
      if (state.phase !== 'roll') return state;
      return { ...state, phase: 'rolling', evt: bump(state, 'roll') };
    }

    case 'ROLL_RESULT': {
      if (state.phase !== 'rolling') return state;
      const value = action.value;
      if (!Number.isInteger(value) || value < 1 || value > 6) return state;
      const sixes = value === 6 ? state.sixes + 1 : 0;
      const stats = value === 6 ? bumpStat(state.stats, state.current, 'sixes', 1) : state.stats;
      if (value === 6 && sixes >= 3 && state.rules.tripleSix) {
        return nextTurn({ ...state, dice: value, sixes: 0, stats }, 'triple');
      }
      return {
        ...state,
        stats,
        phase: 'move',
        dice: value,
        sixes,
        evt: bump(state, value === 6 ? 'six' : 'value'),
      };
    }

    case 'MOVE': {
      if (state.phase !== 'move' || state.dice === null) return state;
      const player = state.players[state.current];
      const token = player.tokens.find((t) => t.id === action.tokenId);
      if (!token) return state;
      const target = targetProgress(token.progress, state.dice, state.rules);
      const steps = target === null ? 0 : target - token.progress;
      if (steps <= 0) return state; // illegal move, ignore
      return {
        ...state,
        phase: 'moving',
        moving: { seat: state.current, tokenId: token.id, steps },
        evt: bump(state, 'step'),
      };
    }

    case 'PASS': {
      if (state.phase !== 'move' || state.dice === null) return state;
      const player = state.players[state.current];
      if (legalTokenIds(player, state.dice, state.rules).length > 0) return state;
      if (state.dice === 6 && state.rules.bonusOnSix) {
        return { ...state, phase: 'roll', dice: null, evt: bump(state, 'pass') };
      }
      return nextTurn(state, 'pass');
    }

    case 'STEP': {
      if (state.phase !== 'moving' || !state.moving) return state;
      const { seat, tokenId, steps } = state.moving;
      const players = state.players.map((p, i) =>
        i !== seat
          ? p
          : {
              ...p,
              tokens: p.tokens.map((t) =>
                t.id === tokenId ? { ...t, progress: t.progress + 1 } : t
              ),
            }
      );
      const remaining = steps - 1;
      if (remaining > 0) {
        return {
          ...state,
          players,
          moving: { seat, tokenId, steps: remaining },
          evt: bump(state, 'step'),
        };
      }
      return settle({ ...state, players, moving: null }, seat, tokenId);
    }

    case 'SET_RULES': {
      const same = (Object.keys(action.rules) as (keyof Rules)[]).every(
        (k) => state.rules[k] === action.rules[k]
      );
      return same ? state : { ...state, rules: action.rules };
    }

    default:
      return state;
  }
}
