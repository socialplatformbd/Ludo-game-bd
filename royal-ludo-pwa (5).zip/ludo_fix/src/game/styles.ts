// Look-and-feel choices.
export type BoardStyle = 'grid' | 'tiles' | 'dots' | 'marble';
export type MoveStyle = 'hop' | 'leap';
export type UiStyle = 'gold' | 'ivory' | 'velvet';

export const BOARD_STYLES: BoardStyle[] = ['grid', 'tiles', 'dots', 'marble'];
export const MOVE_STYLES: MoveStyle[] = ['hop', 'leap'];
export const UI_STYLES: UiStyle[] = ['gold', 'ivory', 'velvet'];
