import type { Color } from './logic';

export type ThemeId =
  | 'royal'
  | 'emerald'
  | 'midnight'
  | 'neon'
  | 'wood'
  | 'marble'
  | 'crimson'
  | 'ocean'
  | 'galaxy'
  | 'sunset'
  | 'classic'
  | 'snow'
  | 'slate'
  | 'rose'
  | 'ice'
  | 'lava'
  | 'carbon';

export interface ThemeDef {
  id: ThemeId;
  tier: 'normal' | 'premium';
  bgInner: string; // centre colour of the board frame
  bgOuter: string; // edge colour of the board frame
  cell: string; // cream track cells
  cellStroke: string;
  yard: string; // inner colour of home yards
  frame: [string, string, string]; // gradient stops for the frame border
  swatch: string; // CSS background used in the theme picker
  pattern?: 'dots' | 'diamonds' | 'stars'; // fine texture on the board frame
}

export const THEMES: Record<ThemeId, ThemeDef> = {
  royal: {
    id: 'royal',
    tier: 'normal',
    bgInner: '#2b4fc0',
    bgOuter: '#0a1a4d',
    cell: '#fcf3dc',
    cellStroke: '#b98a3e',
    yard: '#fff8e6',
    frame: ['#fff1b8', '#d4a017', '#7a4d00'],
    swatch: 'linear-gradient(135deg,#2b4fc0,#0a1a4d 70%,#d4a017)',
  },
  emerald: {
    id: 'emerald',
    tier: 'normal',
    bgInner: '#1f7a4d',
    bgOuter: '#03281a',
    cell: '#f7f1dc',
    cellStroke: '#a9802f',
    yard: '#fdf9ea',
    frame: ['#fff1b8', '#d4a017', '#7a4d00'],
    swatch: 'linear-gradient(135deg,#1f7a4d,#03281a 70%,#d4a017)',
  },
  midnight: {
    id: 'midnight',
    tier: 'normal',
    bgInner: '#4c2a8a',
    bgOuter: '#0a0716',
    cell: '#f1eee6',
    cellStroke: '#8e97a6',
    yard: '#f8f7f2',
    frame: ['#f5f7fa', '#b8c0cc', '#5b6472'],
    swatch: 'linear-gradient(135deg,#4c2a8a,#0a0716 70%,#c0c8d4)',
  },
  neon: {
    id: 'neon',
    tier: 'premium',
    bgInner: '#1b0f4a',
    bgOuter: '#03010d',
    cell: '#1c2146',
    cellStroke: '#22d3ee',
    yard: '#10143a',
    frame: ['#a5f3fc', '#22d3ee', '#0e7490'],
    swatch: 'linear-gradient(135deg,#1b0f4a,#03010d 65%,#22d3ee)',
    pattern: 'diamonds',
  },
  wood: {
    id: 'wood',
    tier: 'normal',
    bgInner: '#9a6330',
    bgOuter: '#3a2010',
    cell: '#f6e6c3',
    cellStroke: '#6b4423',
    yard: '#fbefd2',
    frame: ['#f7dca6', '#b8864b', '#5a3a1a'],
    swatch: 'linear-gradient(135deg,#9a6330,#3a2010 70%,#f7dca6)',
  },
  marble: {
    id: 'marble',
    tier: 'premium',
    bgInner: '#eceef4',
    bgOuter: '#8f95aa',
    cell: '#fcfcfa',
    cellStroke: '#b3ae9f',
    yard: '#ffffff',
    frame: ['#fff1b8', '#d4a017', '#7a4d00'],
    swatch: 'linear-gradient(135deg,#f6f7fb,#8f95aa 70%,#d4a017)',
    pattern: 'diamonds',
  },
  crimson: {
    id: 'crimson',
    tier: 'premium',
    bgInner: '#a3202f',
    bgOuter: '#2a0509',
    cell: '#fbeee3',
    cellStroke: '#b8864b',
    yard: '#fff4ea',
    frame: ['#fff1b8', '#d4a017', '#7a4d00'],
    swatch: 'linear-gradient(135deg,#a3202f,#2a0509 70%,#d4a017)',
    pattern: 'diamonds',
  },
  ocean: {
    id: 'ocean',
    tier: 'premium',
    bgInner: '#0f8a94',
    bgOuter: '#021f2b',
    cell: '#effafa',
    cellStroke: '#5fb3b8',
    yard: '#f6fdfd',
    frame: ['#e0fbff', '#7dd3d8', '#1b6b73'],
    swatch: 'linear-gradient(135deg,#0f8a94,#021f2b 70%,#e0fbff)',
    pattern: 'dots',
  },
  galaxy: {
    id: 'galaxy',
    tier: 'premium',
    bgInner: '#3f2086',
    bgOuter: '#05020e',
    cell: '#ebe6f7',
    cellStroke: '#8b7bd1',
    yard: '#f5f2fc',
    frame: ['#f0e6ff', '#a78bfa', '#4c1d95'],
    swatch: 'linear-gradient(135deg,#3f2086,#05020e 70%,#a78bfa)',
    pattern: 'stars',
  },
  sunset: {
    id: 'sunset',
    tier: 'premium',
    bgInner: '#e8812f',
    bgOuter: '#561808',
    cell: '#fff3dc',
    cellStroke: '#c27a2c',
    yard: '#fff8ea',
    frame: ['#fff1b8', '#e0a52a', '#7a4d00'],
    swatch: 'linear-gradient(135deg,#e8812f,#561808 70%,#fff1b8)',
    pattern: 'dots',
  },
  classic: {
    id: 'classic',
    tier: 'normal',
    bgInner: '#f4f1e8',
    bgOuter: '#cfc8b4',
    cell: '#ffffff',
    cellStroke: '#9a9a9a',
    yard: '#ffffff',
    frame: ['#d1d5db', '#6b7280', '#374151'],
    swatch: 'linear-gradient(135deg,#ffffff,#cfc8b4 70%,#6b7280)',
  },
  snow: {
    id: 'snow',
    tier: 'normal',
    bgInner: '#f8fafc',
    bgOuter: '#b8c4d4',
    cell: '#ffffff',
    cellStroke: '#94a3b8',
    yard: '#ffffff',
    frame: ['#e2e8f0', '#94a3b8', '#475569'],
    swatch: 'linear-gradient(135deg,#f8fafc,#b8c4d4 70%,#475569)',
  },
  slate: {
    id: 'slate',
    tier: 'normal',
    bgInner: '#3a4a63',
    bgOuter: '#0f172a',
    cell: '#e2e8f0',
    cellStroke: '#64748b',
    yard: '#f1f5f9',
    frame: ['#cbd5e1', '#94a3b8', '#475569'],
    swatch: 'linear-gradient(135deg,#3a4a63,#0f172a 70%,#cbd5e1)',
  },
  rose: {
    id: 'rose',
    tier: 'premium',
    bgInner: '#cc8d8d',
    bgOuter: '#4a1f2a',
    cell: '#fdf0ec',
    cellStroke: '#b76e79',
    yard: '#fff6f2',
    frame: ['#ffe4d6', '#e0a38f', '#8a4a3a'],
    swatch: 'linear-gradient(135deg,#cc8d8d,#4a1f2a 70%,#ffe4d6)',
    pattern: 'diamonds',
  },
  ice: {
    id: 'ice',
    tier: 'premium',
    bgInner: '#5aa9e6',
    bgOuter: '#0b2a4a',
    cell: '#f2faff',
    cellStroke: '#7fb6dd',
    yard: '#f8fcff',
    frame: ['#ffffff', '#bfe3ff', '#4d8fbf'],
    swatch: 'linear-gradient(135deg,#5aa9e6,#0b2a4a 70%,#ffffff)',
    pattern: 'stars',
  },
  lava: {
    id: 'lava',
    tier: 'premium',
    bgInner: '#c2410c',
    bgOuter: '#1c0a04',
    cell: '#2b1a14',
    cellStroke: '#fb923c',
    yard: '#1f120d',
    frame: ['#fde68a', '#f97316', '#7c2d12'],
    swatch: 'linear-gradient(135deg,#c2410c,#1c0a04 70%,#f97316)',
    pattern: 'dots',
  },
  carbon: {
    id: 'carbon',
    tier: 'premium',
    bgInner: '#2f2f35',
    bgOuter: '#050506',
    cell: '#1d1d21',
    cellStroke: '#d4a017',
    yard: '#141416',
    frame: ['#fff1b8', '#d4a017', '#7a4d00'],
    swatch: 'linear-gradient(135deg,#2f2f35,#050506 70%,#d4a017)',
    pattern: 'diamonds',
  },
};

export interface Palette {
  main: string;
  dark: string;
  light: string;
  hi: string; // token gloss highlight
  mid: string; // token body
  lo: string; // token shadow edge
}

export const PALETTE: Record<Color, Palette> = {
  red: { main: '#e53e5a', dark: '#9b1c36', light: '#ffd7de', hi: '#ffb3c0', mid: '#e11d48', lo: '#7f1028' },
  green: { main: '#22a35a', dark: '#14532d', light: '#d6f5e1', hi: '#b8f5cf', mid: '#16a34a', lo: '#0b4a25' },
  yellow: { main: '#f5b82e', dark: '#a16207', light: '#fff4c2', hi: '#fff9d6', mid: '#facc15', lo: '#a16207' },
  blue: { main: '#2f6fe0', dark: '#1e3a8a', light: '#d7e5ff', hi: '#b6d2ff', mid: '#2563eb', lo: '#1e3a8a' },
};
