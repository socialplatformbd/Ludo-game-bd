// Small synthesised sound engine (Web Audio API). No audio files, no network.
// The AudioContext is only created after a user tap, which browsers require.

let ctx: AudioContext | null = null;
let sfxBus: GainNode | null = null;
let musicBus: GainNode | null = null;
let sfxOn = true;
let musicOn = false;
let musicTimer: number | undefined;
let chordIndex = 0;

// Chords for the calm background loop: C, Am, F, G (frequencies in Hz).
const CHORDS: number[][] = [
  [261.63, 329.63, 392.0],
  [220.0, 261.63, 329.63],
  [174.61, 220.0, 261.63],
  [196.0, 246.94, 293.66],
];

function getContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!ctx) {
    const Ctor = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    try {
      ctx = new Ctor();
    } catch {
      return null;
    }
    const master = ctx.createGain();
    master.gain.value = 0.8;
    master.connect(ctx.destination);
    sfxBus = ctx.createGain();
    sfxBus.gain.value = 0.9;
    sfxBus.connect(master);
    musicBus = ctx.createGain();
    musicBus.gain.value = 0.07;
    musicBus.connect(master);
  }
  if (ctx.state === 'suspended') void ctx.resume().catch(() => undefined);
  return ctx;
}

function tone(
  freq: number,
  start: number,
  dur: number,
  type: OscillatorType,
  vol: number,
  bus: GainNode | null,
  slideTo?: number
) {
  const c = ctx;
  if (!c || !bus) return;
  const osc = c.createOscillator();
  const gain = c.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, start);
  if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, start + dur);
  gain.gain.setValueAtTime(0.0001, start);
  gain.gain.exponentialRampToValueAtTime(vol, start + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.0001, start + dur);
  osc.connect(gain);
  gain.connect(bus);
  osc.start(start);
  osc.stop(start + dur + 0.05);
}

function noiseBurst(start: number, dur: number, vol: number, cutoff: number) {
  const c = ctx;
  if (!c || !sfxBus) return;
  const length = Math.floor(c.sampleRate * dur);
  const buffer = c.createBuffer(1, length, c.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < length; i += 1) data[i] = (Math.random() * 2 - 1) * (1 - i / length);
  const src = c.createBufferSource();
  const filter = c.createBiquadFilter();
  const gain = c.createGain();
  filter.type = 'bandpass';
  filter.frequency.value = cutoff;
  gain.gain.value = vol;
  src.buffer = buffer;
  src.connect(filter);
  filter.connect(gain);
  gain.connect(sfxBus);
  src.start(start);
}

export function playSfx(kind: string) {
  if (!sfxOn) return;
  const c = getContext();
  if (!c) return;
  const t = c.currentTime + 0.01;
  switch (kind) {
    case 'roll':
      for (let i = 0; i < 5; i += 1) noiseBurst(t + i * 0.07, 0.05, 0.5, 1400 + i * 300);
      break;
    case 'step':
      tone(620, t, 0.05, 'triangle', 0.07, sfxBus);
      break;
    case 'value':
      tone(784, t, 0.12, 'sine', 0.18, sfxBus);
      break;
    case 'land':
      tone(440, t, 0.1, 'sine', 0.2, sfxBus, 330);
      tone(660, t + 0.07, 0.12, 'triangle', 0.12, sfxBus);
      break;
    case 'six':
      [523.25, 659.25, 783.99].forEach((f, i) => tone(f, t + i * 0.09, 0.22, 'triangle', 0.22, sfxBus));
      break;
    case 'capture':
      tone(520, t, 0.3, 'sawtooth', 0.09, sfxBus, 90);
      noiseBurst(t, 0.22, 0.35, 900);
      break;
    case 'home':
      [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => tone(f, t + i * 0.1, 0.35, 'sine', 0.22, sfxBus));
      break;
    case 'pass':
    case 'triple':
      tone(330, t, 0.22, 'sine', 0.14, sfxBus, 220);
      break;
    case 'win':
      [0, 1, 2, 3, 4].forEach((i) => {
        const base = [523.25, 587.33, 659.25, 783.99, 1046.5][i];
        tone(base, t + i * 0.12, 0.5, 'triangle', 0.2, sfxBus);
      });
      [261.63, 329.63, 392.0].forEach((f) => tone(f, t + 0.6, 1.2, 'sine', 0.16, sfxBus));
      break;
    default:
      break;
  }
}

function playChord() {
  const c = ctx;
  if (!c || !musicBus || !musicOn) return;
  const t = c.currentTime + 0.05;
  const chord = CHORDS[chordIndex % CHORDS.length];
  chordIndex += 1;
  chord.forEach((f) => tone(f, t, 2.4, 'sine', 0.5, musicBus));
  tone(chord[0] / 2, t, 2.4, 'triangle', 0.6, musicBus);
  // A soft sparkle note on top of the chord.
  tone(chord[2] * 2, t + 1.2, 0.8, 'sine', 0.35, musicBus);
}

function startMusicLoop() {
  if (musicTimer !== undefined) return;
  playChord();
  musicTimer = window.setInterval(playChord, 2400);
}

function stopMusicLoop() {
  if (musicTimer !== undefined) {
    window.clearInterval(musicTimer);
    musicTimer = undefined;
  }
}

/** Call once on the first user tap (browsers block audio before that). */
export function unlockAudio() {
  getContext();
  if (musicOn) startMusicLoop();
}

export function setSfx(on: boolean) {
  sfxOn = on;
}

export function setMusic(on: boolean) {
  musicOn = on;
  if (!on) {
    stopMusicLoop();
    return;
  }
  // Only start once the audio context exists (created after a user tap).
  if (ctx) startMusicLoop();
}
