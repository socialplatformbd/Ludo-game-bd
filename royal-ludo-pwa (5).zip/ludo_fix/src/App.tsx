import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import {
  chooseCpuMove,
  createGame,
  legalTokenIds,
  reducer,
  type Action,
  type EventKind,
  type GameState,
  type Level,
  type Rules,
  type SeatInit,
} from './game/logic';
import { makeT } from './game/i18n';
import { THEMES } from './game/themes';
import { playSfx, setMusic, setSfx, unlockAudio } from './game/audio';
import { TIMING, stepTime } from './game/speed';
import { loadGame, loadSettings, loadStats, saveGame, saveSettings, saveStats, type Settings, type Stats } from './game/storage';
import { MenuScreen } from './components/MenuScreen';
import { SetupScreen } from './components/SetupScreen';
import { GameScreen } from './components/GameScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { RulesScreen } from './components/RulesScreen';
import { AboutScreen } from './components/AboutScreen';
import { StatsScreen } from './components/StatsScreen';
import { Splash } from './components/Splash';

type Screen = 'home' | 'setup' | 'game' | 'settings' | 'rules' | 'about' | 'stats';

const VIBRATION: Partial<Record<EventKind, number | number[]>> = {
  six: 25,
  capture: 70,
  home: [40, 60, 40],
  win: [80, 60, 80, 60, 180],
};

function buzz(kind: EventKind) {
  const pattern = VIBRATION[kind];
  if (pattern !== undefined && typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
    navigator.vibrate(pattern);
  }
}

export default function App() {
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [game, setGame] = useState<GameState | null>(loadGame);
  const [stack, setStack] = useState<Screen[]>(['home']);
  const [stats, setStats] = useState<Stats>(loadStats);
  const [splash, setSplash] = useState(true);

  const t = useMemo(() => makeT(settings.lang), [settings.lang]);
  const theme = THEMES[settings.theme];
  const screen = stack[stack.length - 1];

  const go = useCallback((next: Screen) => setStack((s) => [...s, next]), []);
  const back = useCallback(() => setStack((s) => (s.length > 1 ? s.slice(0, -1) : s)), []);
  const goHome = useCallback(() => setStack(['home']), []);

  const dispatch = useCallback((action: Action) => {
    setGame((g) => (g ? reducer(g, action) : g));
  }, []);

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    setSettings((s) => ({ ...s, ...patch }));
  }, []);

  const updateRules = useCallback((patch: Partial<Rules>) => {
    setSettings((s) => ({ ...s, rules: { ...s.rules, ...patch } }));
  }, []);

  // ----- Audio and document settings -----
  useEffect(() => setSfx(settings.sound), [settings.sound]);
  useEffect(() => setMusic(settings.music), [settings.music]);
  useEffect(() => {
    // Browsers only allow audio after a user gesture, so unlock on the first tap.
    const unlock = () => unlockAudio();
    window.addEventListener('pointerdown', unlock, { once: true });
    return () => window.removeEventListener('pointerdown', unlock);
  }, []);
  useEffect(() => {
    document.documentElement.lang = settings.lang;
  }, [settings.lang]);

  // App style (colours of the whole UI) is applied through an attribute on <html>.
  useEffect(() => {
    document.documentElement.dataset.ui = settings.uiStyle;
  }, [settings.uiStyle]);

  // Opening animation: short, and a tap skips it.
  useEffect(() => {
    const id = window.setTimeout(() => setSplash(false), 1350);
    return () => window.clearTimeout(id);
  }, []);

  // ----- Persistence -----
  useEffect(() => saveSettings(settings), [settings]);
  useEffect(() => saveGame(game), [game]);
  useEffect(() => saveStats(stats), [stats]);

  // Add a finished match to the lifetime stats exactly once (a match loaded already finished is not recounted).
  const counted = useRef<GameState | null>(game);
  useEffect(() => {
    if (!game || game.phase !== 'over' || counted.current === game) return;
    counted.current = game;
    const humans = game.players.map((p, i) => (p.cpu ? -1 : i)).filter((i) => i >= 0);
    if (humans.length === 0) return;
    setStats((s) => ({
      games: s.games + 1,
      wins: s.wins + (humans.includes(game.winners[0]) ? 1 : 0),
      captures: s.captures + humans.reduce((n, i) => n + (game.stats[i]?.captures ?? 0), 0),
      sixes: s.sixes + humans.reduce((n, i) => n + (game.stats[i]?.sixes ?? 0), 0),
    }));
  }, [game]);

  // Keep the running match in sync with the house rules chosen in settings.
  useEffect(() => {
    dispatch({ type: 'SET_RULES', rules: settings.rules });
  }, [settings.rules, dispatch]);

  // Guard: if the game screen is open without a match, go back to the menu.
  useEffect(() => {
    if (screen === 'game' && !game) setStack(['home']);
  }, [screen, game]);

  // ----- Sound and vibration on every game event -----
  const lastEvent = useRef(game?.evt.n ?? -1);
  useEffect(() => {
    if (!game || game.evt.n === lastEvent.current) return;
    lastEvent.current = game.evt.n;
    playSfx(game.evt.kind);
    if (settings.vibration) buzz(game.evt.kind);
  }, [game, settings.vibration]);

  // ----- Automatic turn engine (dice rolls, computer moves, token steps) -----
  useEffect(() => {
    if (!game || screen !== 'game') return;
    const player = game.players[game.current];
    let timer: number | undefined;
    const timing = TIMING[settings.speed];

    switch (game.phase) {
      case 'roll':
        if (player.cpu) timer = window.setTimeout(() => dispatch({ type: 'ROLL_START' }), timing.cpuRoll);
        break;
      case 'rolling':
        timer = window.setTimeout(
          () => dispatch({ type: 'ROLL_RESULT', value: 1 + Math.floor(Math.random() * 6) }),
          timing.rolling
        );
        break;
      case 'move': {
        const legal = game.dice !== null ? legalTokenIds(player, game.dice, game.rules) : [];
        if (legal.length === 0) {
          timer = window.setTimeout(() => dispatch({ type: 'PASS' }), timing.pass);
        } else if (player.cpu) {
          timer = window.setTimeout(() => {
            const tokenId = chooseCpuMove(game);
            if (tokenId !== null) dispatch({ type: 'MOVE', tokenId });
          }, timing.cpuMove);
        } else if (settings.autoMove && legal.length === 1) {
          timer = window.setTimeout(() => dispatch({ type: 'MOVE', tokenId: legal[0] }), timing.auto);
        }
        break;
      }
      case 'moving':
        timer = window.setTimeout(() => dispatch({ type: 'STEP' }), stepTime(settings.speed, settings.moveStyle));
        break;
      default:
        break;
    }

    return () => {
      if (timer !== undefined) window.clearTimeout(timer);
    };
  }, [game, screen, dispatch, settings.speed, settings.autoMove, settings.moveStyle]);

  // ----- Match actions -----
  const startMatch = (seats: SeatInit[], level: Level) => {
    // Remember player 1's name and avatar for next time.
    if (!seats[0].cpu) {
      updateSettings({ profileName: seats[0].name ?? '', profileAvatar: seats[0].avatar ?? settings.profileAvatar });
    }
    setGame(createGame(seats, settings.rules, level));
    setStack(['game']);
  };

  const playAgain = () => {
    if (!game) return;
    setGame(
      createGame(
        game.players.map((p) => ({ cpu: p.cpu, name: p.name, avatar: p.avatar })),
        settings.rules,
        game.level
      )
    );
  };

  const resetGame = () => {
    setGame(null);
    setStack(['home']);
  };

  const canContinue = !!game && game.phase !== 'over';

  let content: ReactNode;
  switch (screen) {
    case 'home':
      content = (
        <MenuScreen
          t={t}
          canContinue={canContinue}
          onPlay={() => go('setup')}
          onContinue={() => go('game')}
          onRules={() => go('rules')}
          onSettings={() => go('settings')}
          onAbout={() => go('about')}
          onStats={() => go('stats')}
        />
      );
      break;
    case 'setup':
      content = (
        <SetupScreen
          t={t}
          profileName={settings.profileName}
          profileAvatar={settings.profileAvatar}
          onStart={startMatch}
          onBack={back}
        />
      );
      break;
    case 'game':
      content = game ? (
        <GameScreen
          t={t}
          game={game}
          theme={theme}
          speed={settings.speed}
          tokenStyle={settings.tokenStyle}
          boardStyle={settings.boardStyle}
          moveStyle={settings.moveStyle}
          dispatch={dispatch}
          onHome={goHome}
          onPlayAgain={playAgain}
        />
      ) : null;
      break;
    case 'settings':
      content = (
        <SettingsScreen
          t={t}
          settings={settings}
          hasGame={!!game}
          onChange={updateSettings}
          onReset={resetGame}
          onRules={() => go('rules')}
          onAbout={() => go('about')}
          onBack={back}
        />
      );
      break;
    case 'rules':
      content = <RulesScreen t={t} rules={settings.rules} onChange={updateRules} onBack={back} />;
      break;
    case 'about':
      content = <AboutScreen t={t} onBack={back} />;
      break;
    case 'stats':
      content = <StatsScreen t={t} stats={stats} onBack={back} />;
      break;
    default:
      content = null;
  }

  return (
    <div className="min-h-dvh">
      {content}
      {splash && <Splash t={t} onDone={() => setSplash(false)} />}
    </div>
  );
}
