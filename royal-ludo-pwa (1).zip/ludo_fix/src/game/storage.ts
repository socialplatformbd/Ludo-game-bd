// Local-only persistence (localStorage). Nothing leaves the device.
// Saved data is validated before use, so a corrupted value can never crash the app.

import { COLORS, DEFAULT_RULES, HOME, type GameState, type Rules } from './logic';
import type { Lang } from './i18n';
import type { ThemeId } from './themes';

export interface Settings {
  sound: boolean;
  music: boolean;
  vibration: boolean;
  theme: ThemeId;
  lang: Lang;
  rules: Rules;
}

export const DEFAULT_SETTINGS: Settings = {
  sound: true,
  music: false,
  vibration: true,
  theme: 'royal',
  lang: 'en',
  rules: DEFAULT_RULES,
};

const SETTINGS_KEY = 'royal-ludo:settings:v1';
const GAME_KEY = 'royal-ludo:game:v1';

function readRaw(key: string): string | null {
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

function writeRaw(key: string, value: string | null) {
  try {
    if (value === null) window.localStorage.removeItem(key);
    else window.localStorage.setItem(key, value);
  } catch {
    // Storage full or blocked. The game still works, it just will not persist.
  }
}

export function loadSettings(): Settings {
  const raw = readRaw(SETTINGS_KEY);
  if (!raw) return DEFAULT_SETTINGS;
  try {
    const data = JSON.parse(raw) as Partial<Settings>;
    const rules = { ...DEFAULT_RULES };
    const savedRules = (data.rules ?? {}) as Partial<Record<keyof Rules, unknown>>;
    (Object.keys(DEFAULT_RULES) as (keyof Rules)[]).forEach((k) => {
      if (typeof savedRules[k] === 'boolean') rules[k] = savedRules[k] as boolean;
    });
    return {
      sound: typeof data.sound === 'boolean' ? data.sound : DEFAULT_SETTINGS.sound,
      music: typeof data.music === 'boolean' ? data.music : DEFAULT_SETTINGS.music,
      vibration: typeof data.vibration === 'boolean' ? data.vibration : DEFAULT_SETTINGS.vibration,
      theme: data.theme === 'royal' || data.theme === 'emerald' || data.theme === 'midnight'
        ? data.theme
        : DEFAULT_SETTINGS.theme,
      lang: data.lang === 'en' || data.lang === 'bn' ? data.lang : DEFAULT_SETTINGS.lang,
      rules,
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: Settings) {
  writeRaw(SETTINGS_KEY, JSON.stringify(settings));
}

function isValidGame(data: unknown): data is GameState {
  if (!data || typeof data !== 'object') return false;
  const g = data as Partial<GameState>;
  if (!Array.isArray(g.players) || g.players.length < 2 || g.players.length > 4) return false;
  if (!Number.isInteger(g.current) || g.current! < 0 || g.current! >= g.players.length) return false;
  if (!['roll', 'rolling', 'move', 'moving', 'over'].includes(String(g.phase))) return false;
  if (g.phase === 'moving' && (!g.moving || !Number.isInteger(g.moving.seat) || !Number.isInteger(g.moving.tokenId) || !Number.isInteger(g.moving.steps) || g.moving.seat < 0 || g.moving.seat >= g.players.length || g.moving.tokenId < 0 || g.moving.tokenId > 3 || g.moving.steps < 1 || g.moving.steps > 57)) return false;
  // A 'move' phase without a dice value could never continue (the game would freeze).
  if (g.phase === 'move' && (g.dice === null || g.dice === undefined)) return false;
  if (!Array.isArray(g.winners) || !g.winners.every((w) => Number.isInteger(w) && w >= 0 && w < g.players!.length)) return false;
  if (g.dice !== null && g.dice !== undefined && (!Number.isInteger(g.dice) || g.dice < 1 || g.dice > 6)) return false;
  const playersOk = g.players.every(
    (p) =>
      p !== null &&
      typeof p === 'object' &&
      COLORS.includes(p.color) &&
      typeof p.cpu === 'boolean' &&
      Array.isArray(p.tokens) &&
      p.tokens.length === 4 &&
      p.tokens.every(
        (t, i) => t.id === i && Number.isInteger(t.progress) && t.progress >= 0 && t.progress <= HOME
      )
  );
  return playersOk;
}

export function loadGame(): GameState | null {
  const raw = readRaw(GAME_KEY);
  if (!raw) return null;
  try {
    const data: unknown = JSON.parse(raw);
    if (!isValidGame(data)) return null;
    return {
      ...data,
      rules: { ...DEFAULT_RULES, ...data.rules },
      evt: data.evt ?? { kind: 'start', n: 0 },
      dice: typeof data.dice === 'number' ? data.dice : null,
      sixes: typeof data.sixes === 'number' ? data.sixes : 0,
    };
  } catch {
    return null;
  }
}

export function saveGame(game: GameState | null) {
  writeRaw(GAME_KEY, game ? JSON.stringify(game) : null);
}
