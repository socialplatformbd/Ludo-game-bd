import type { Color } from './logic';

export type ThemeId = 'royal' | 'emerald' | 'midnight';

export interface ThemeDef {
  id: ThemeId;
  bgInner: string; // centre colour of the board frame
  bgOuter: string; // edge colour of the board frame
  cell: string; // cream track cells
  cellStroke: string;
  yard: string; // inner colour of home yards
  frame: [string, string, string]; // gradient stops for the frame border
  swatch: string; // CSS background used in the theme picker
}

export const THEMES: Record<ThemeId, ThemeDef> = {
  royal: {
    id: 'royal',
    bgInner: '#2b4fc0',
    bgOuter: '#0a1a4d',
    cell: '#fcf3dc',
    cellStroke: '#b98a3e',
    yard: '#fff8e6',
    frame: ['#fff1b8', '#d4a017', '#7a4d00'],
    swatch: 'linear-gradient(135deg,#2b4fc0,#0a1a4d 70%,#d4a017)',
  },
  emerald: {
    id: 'emerald',
    bgInner: '#1f7a4d',
    bgOuter: '#03281a',
    cell: '#f7f1dc',
    cellStroke: '#a9802f',
    yard: '#fdf9ea',
    frame: ['#fff1b8', '#d4a017', '#7a4d00'],
    swatch: 'linear-gradient(135deg,#1f7a4d,#03281a 70%,#d4a017)',
  },
  midnight: {
    id: 'midnight',
    bgInner: '#4c2a8a',
    bgOuter: '#0a0716',
    cell: '#f1eee6',
    cellStroke: '#8e97a6',
    yard: '#f8f7f2',
    frame: ['#f5f7fa', '#b8c0cc', '#5b6472'],
    swatch: 'linear-gradient(135deg,#4c2a8a,#0a0716 70%,#c0c8d4)',
  },
};

export interface Palette {
  main: string;
  dark: string;
  light: string;
  hi: string; // token gloss highlight
  mid: string; // token body
  lo: string; // token shadow edge
}

export const PALETTE: Record<Color, Palette> = {
  red: { main: '#e53e5a', dark: '#9b1c36', light: '#ffd7de', hi: '#ffb3c0', mid: '#e11d48', lo: '#7f1028' },
  green: { main: '#22a35a', dark: '#14532d', light: '#d6f5e1', hi: '#b8f5cf', mid: '#16a34a', lo: '#0b4a25' },
  yellow: { main: '#f5b82e', dark: '#a16207', light: '#fff4c2', hi: '#fff9d6', mid: '#facc15', lo: '#a16207' },
  blue: { main: '#2f6fe0', dark: '#1e3a8a', light: '#d7e5ff', hi: '#b6d2ff', mid: '#2563eb', lo: '#1e3a8a' },
};
