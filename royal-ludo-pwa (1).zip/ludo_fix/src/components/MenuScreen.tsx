import type { T } from '../game/i18n';
import { PALETTE } from '../game/themes';
import { COLORS } from '../game/logic';
import { Button, CrownIcon, DevCredit } from './ui';

interface Props {
  t: T;
  canContinue: boolean;
  onPlay: () => void;
  onContinue: () => void;
  onRules: () => void;
  onSettings: () => void;
  onAbout: () => void;
}

export function MenuScreen({ t, canContinue, onPlay, onContinue, onRules, onSettings, onAbout }: Props) {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-between px-6 pb-6 pt-[calc(env(safe-area-inset-top)+28px)]">
      <div className="flex w-full max-w-sm flex-col items-center gap-6">
        <div className="flex gap-3" aria-hidden="true">
          {COLORS.map((c) => (
            <span
              key={c}
              className="h-7 w-7 rounded-full border-2 border-white/80 shadow-lg"
              style={{
                background: `radial-gradient(circle at 35% 30%, ${PALETTE[c].hi}, ${PALETTE[c].mid} 55%, ${PALETTE[c].lo})`,
              }}
            />
          ))}
        </div>

        <div className="crown-badge">
          <CrownIcon className="h-12 w-16 drop-shadow-lg" />
        </div>

        <div className="text-center">
          <h1 className="font-display gold-text text-5xl font-black tracking-wide">{t('appName')}</h1>
          <p className="mt-3 text-xs uppercase tracking-[0.3em] text-amber-200/85">{t('tagline')}</p>
        </div>

        <div className="flex w-full flex-col gap-3 pt-2">
          <Button onClick={onPlay} className="w-full text-lg">
            {t('play')}
          </Button>
          {canContinue && (
            <Button variant="ghost" onClick={onContinue} className="w-full">
              {t('continueGame')}
            </Button>
          )}
          <div className="grid grid-cols-2 gap-3">
            <Button variant="ghost" onClick={onRules}>
              {t('rules')}
            </Button>
            <Button variant="ghost" onClick={onSettings}>
              {t('settings')}
            </Button>
          </div>
          <Button variant="ghost" onClick={onAbout} className="w-full">
            {t('about')}
          </Button>
        </div>
      </div>

      <div className="pt-10 text-center">
        <DevCredit t={t} />
        <p className="mt-2 text-[11px] text-amber-100/50">{t('noAds')}</p>
      </div>
    </div>
  );
}
