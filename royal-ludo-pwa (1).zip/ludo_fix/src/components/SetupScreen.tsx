import { useState } from 'react';
import { seatColors } from '../game/logic';
import { colorName, type T } from '../game/i18n';
import { PALETTE } from '../game/themes';
import { Button, Card, Page } from './ui';

interface Props {
  t: T;
  onStart: (seats: { cpu: boolean }[]) => void;
  onBack: () => void;
}

const COUNTS = [2, 3, 4];

export function SetupScreen({ t, onStart, onBack }: Props) {
  const [count, setCount] = useState(2);
  // Default: seat 1 is the human, the rest are computers. Change any seat to human for local play.
  const [cpu, setCpu] = useState<boolean[]>([false, true, true, true]);
  const colors = seatColors(count);

  return (
    <Page title={t('newMatch')} t={t} onBack={onBack}>
      <Card>
        <p className="mb-3 text-sm font-semibold uppercase tracking-widest text-amber-200/90">{t('players')}</p>
        <div className="grid grid-cols-3 gap-2">
          {COUNTS.map((n) => (
            <button
              key={n}
              type="button"
              aria-pressed={count === n}
              onClick={() => setCount(n)}
              className={`min-h-14 rounded-2xl text-2xl font-black transition ${
                count === n ? 'btn-gold' : 'btn-ghost'
              }`}
            >
              {n}
            </button>
          ))}
        </div>
      </Card>

      <Card>
        <div className="flex flex-col gap-3">
          {Array.from({ length: count }, (_, i) => {
            const color = colors[i];
            const isCpu = cpu[i];
            return (
              <div key={i} className="flex items-center gap-3">
                <span
                  className="h-6 w-6 shrink-0 rounded-full border-2 border-white/80 shadow"
                  style={{
                    background: `radial-gradient(circle at 35% 30%, ${PALETTE[color].hi}, ${PALETTE[color].mid} 60%, ${PALETTE[color].lo})`,
                  }}
                />
                <span className="min-w-0 flex-1 truncate text-[15px] font-semibold text-amber-50">
                  {colorName(color, t)}
                </span>
                <div className="flex overflow-hidden rounded-xl border border-amber-300/40 text-sm font-bold">
                  <button
                    type="button"
                    aria-pressed={!isCpu}
                    onClick={() => setCpu((prev) => prev.map((v, j) => (j === i ? false : v)))}
                    className={`min-h-10 px-3 transition ${!isCpu ? 'btn-gold' : 'bg-white/5 text-amber-100/80'}`}
                  >
                    {t('human')}
                  </button>
                  <button
                    type="button"
                    aria-pressed={isCpu}
                    onClick={() => setCpu((prev) => prev.map((v, j) => (j === i ? true : v)))}
                    className={`min-h-10 px-3 transition ${isCpu ? 'btn-gold' : 'bg-white/5 text-amber-100/80'}`}
                  >
                    {t('computer')}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      <p className="px-1 text-center text-sm text-amber-100/70">{t('setupHint')}</p>

      <Button className="mt-2 w-full text-lg" onClick={() => onStart(Array.from({ length: count }, (_, i) => ({ cpu: cpu[i] })))}>
        {t('startGame')}
      </Button>
    </Page>
  );
}
