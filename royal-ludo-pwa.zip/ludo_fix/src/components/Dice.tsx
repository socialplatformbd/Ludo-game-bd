import { useEffect, useState } from 'react';

// Pip positions on a 100 x 100 face.
const PIPS: Record<number, [number, number][]> = {
  1: [[50, 50]],
  2: [[28, 28], [72, 72]],
  3: [[28, 28], [50, 50], [72, 72]],
  4: [[28, 28], [72, 28], [28, 72], [72, 72]],
  5: [[28, 28], [72, 28], [50, 50], [28, 72], [72, 72]],
  6: [[28, 26], [72, 26], [28, 50], [72, 50], [28, 74], [72, 74]],
};

interface Props {
  value: number | null;
  rolling: boolean;
}

export function Dice({ value, rolling }: Props) {
  const [tumble, setTumble] = useState(1);

  // While rolling, flash random faces so the dice looks like it is tumbling.
  useEffect(() => {
    if (!rolling) return;
    const id = window.setInterval(() => setTumble(1 + Math.floor(Math.random() * 6)), 80);
    return () => window.clearInterval(id);
  }, [rolling]);

  const face = rolling ? tumble : value ?? 1;
  const idle = value === null && !rolling;

  return (
    <div
      className={`dice-wrap ${rolling ? 'dice-rolling' : ''} ${idle ? 'opacity-60' : ''}`}
      role="img"
      aria-label={`Dice showing ${face}`}
    >
      <svg viewBox="0 0 100 100" className="block h-full w-full">
        <defs>
          <linearGradient id="diceFace" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#fffdf5" />
            <stop offset="1" stopColor="#efdca4" />
          </linearGradient>
        </defs>
        <rect x={3} y={3} width={94} height={94} rx={20} fill="url(#diceFace)" stroke="#d4a017" strokeWidth={3} />
        <rect x={9} y={9} width={82} height={82} rx={15} fill="none" stroke="#e7c35a" strokeWidth={1} opacity={0.7} />
        {PIPS[face].map(([x, y], i) => (
          <circle key={i} cx={x} cy={y} r={8} fill={face === 1 ? '#b91c1c' : '#1e1b4b'} />
        ))}
      </svg>
    </div>
  );
}
