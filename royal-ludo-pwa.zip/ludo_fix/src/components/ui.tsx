import type { ButtonHTMLAttributes, ReactNode } from 'react';
import type { T } from '../game/i18n';

export const TELEGRAM_URL = 'https://t.me/appdevbyrakib';

type ButtonVariant = 'gold' | 'ghost' | 'danger';

export function Button({
  variant = 'gold',
  className = '',
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: ButtonVariant }) {
  const variantClass = variant === 'gold' ? 'btn-gold' : variant === 'danger' ? 'btn-danger' : 'btn-ghost';
  return (
    <button
      type="button"
      className={`inline-flex min-h-12 items-center justify-center gap-2 rounded-2xl px-5 py-3 text-base font-bold transition active:scale-[0.97] disabled:pointer-events-none disabled:opacity-40 select-none ${variantClass} ${className}`}
      {...rest}
    >
      {children}
    </button>
  );
}

export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <div className={`panel rounded-3xl p-4 ${className}`}>{children}</div>;
}

export function Toggle({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={`relative h-8 w-14 shrink-0 rounded-full transition ${checked ? 'toggle-on' : 'toggle-off'}`}
    >
      <span
        className={`absolute top-1 h-6 w-6 rounded-full bg-white shadow-md transition-all ${
          checked ? 'left-7' : 'left-1'
        }`}
      />
    </button>
  );
}

export function SettingRow({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex min-h-12 items-center justify-between gap-3 py-2">
      <span className="text-[15px] text-amber-50">{label}</span>
      {children}
    </div>
  );
}

export function BackIcon({ className = 'h-5 w-5' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M15 5l-7 7 7 7" />
    </svg>
  );
}

export function Page({
  title,
  t,
  onBack,
  children,
}: {
  title: string;
  t: T;
  onBack?: () => void;
  children: ReactNode;
}) {
  return (
    <div className="flex min-h-dvh flex-col">
      <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-amber-300/15 bg-[#081437]/85 px-4 pb-3 pt-[calc(env(safe-area-inset-top)+12px)] backdrop-blur-md">
        {onBack && (
          <button type="button" onClick={onBack} className="icon-btn" aria-label={t('back')}>
            <BackIcon />
          </button>
        )}
        <h1 className="font-display gold-text flex-1 truncate text-2xl font-bold">{title}</h1>
      </header>
      <main className="mx-auto flex w-full max-w-md flex-1 flex-col gap-4 px-4 pb-12 pt-4">{children}</main>
    </div>
  );
}

export function CrownIcon({ className = '' }: { className?: string }) {
  return (
    <svg viewBox="-12 -10 24 20" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="crownGold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff3b0" />
          <stop offset="0.5" stopColor="#f5c542" />
          <stop offset="1" stopColor="#b7791f" />
        </linearGradient>
      </defs>
      <path
        d="M-9 4 L-10.5 -5 L-4.5 0.5 L0 -7 L4.5 0.5 L10.5 -5 L9 4 Z"
        fill="url(#crownGold)"
        stroke="#7a4d00"
        strokeWidth={0.6}
        strokeLinejoin="round"
      />
      <rect x={-9} y={5} width={18} height={3} rx={1} fill="url(#crownGold)" stroke="#7a4d00" strokeWidth={0.6} />
      <circle cx={0} cy={-7.6} r={1.1} fill="#fff7c2" />
      <circle cx={-10.5} cy={-5.6} r={0.9} fill="#fff7c2" />
      <circle cx={10.5} cy={-5.6} r={0.9} fill="#fff7c2" />
    </svg>
  );
}

export function DevCredit({ t }: { t: T }) {
  return (
    <p className="text-center text-xs text-amber-100/75">
      {t('devCredit')} ·{' '}
      <a
        href={TELEGRAM_URL}
        target="_blank"
        rel="noopener noreferrer"
        className="font-semibold text-amber-300 underline underline-offset-2"
      >
        t.me/appdevbyrakib
      </a>
    </p>
  );
}
