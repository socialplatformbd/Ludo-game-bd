import { Board } from './Board';
import { Dice } from './Dice';
import { Button, CrownIcon, DevCredit } from './ui';
import { homeCount, legalTokenIds, type Action, type GameState, type Player } from '../game/logic';
import { colorName, type Key, type T } from '../game/i18n';
import { PALETTE, type ThemeDef } from '../game/themes';

const RANK_KEYS: Key[] = ['rank1', 'rank2', 'rank3', 'rank4'];

export function playerLabel(player: Player, seat: number, t: T): string {
  return player.cpu ? t('cpuName', { n: seat + 1 }) : t('playerName', { n: seat + 1 });
}

interface Props {
  t: T;
  game: GameState;
  theme: ThemeDef;
  dispatch: (action: Action) => void;
  onHome: () => void;
  onPlayAgain: () => void;
}

function orbStyle(color: keyof typeof PALETTE) {
  const p = PALETTE[color];
  return {
    background: `radial-gradient(circle at 35% 30%, ${p.hi}, ${p.mid} 60%, ${p.lo})`,
  };
}

export function GameScreen({ t, game, theme, dispatch, onHome, onPlayAgain }: Props) {
  const seat = game.current;
  const player = game.players[seat];
  const isHuman = !player.cpu;
  const legal =
    game.phase === 'move' && game.dice !== null ? legalTokenIds(player, game.dice, game.rules) : [];
  const canRoll = game.phase === 'roll' && isHuman;
  const highlight = isHuman ? legal : [];
  const currentName = playerLabel(player, seat, t);

  let status: string;
  if (game.evt.kind === 'triple' && game.phase === 'roll') {
    status = t('triple');
  } else if (game.phase === 'roll') {
    status = isHuman ? t('yourTurn') : t('cpuPlaying', { name: currentName });
  } else if (game.phase === 'rolling') {
    status = t('rolling');
  } else if (game.phase === 'move') {
    if (legal.length === 0) status = t('noMoves');
    else status = isHuman ? t('tapToken') : t('cpuPlaying', { name: currentName });
  } else if (game.phase === 'moving') {
    status = t('moving');
  } else {
    status = '';
  }

  const winnerSeat = game.winners[0] ?? 0;

  return (
    <div className="flex min-h-dvh flex-col">
      <header className="flex items-center gap-3 px-4 pb-2 pt-[calc(env(safe-area-inset-top)+10px)]">
        <button type="button" onClick={onHome} className="icon-btn" aria-label={t('home')}>
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M3 11l9-7 9 7" />
            <path d="M5 10v10h14V10" />
          </svg>
        </button>
        <div className="flex min-w-0 flex-1 items-center justify-center">
          {game.phase !== 'over' && (
            <span className="turn-chip">
              <span className="h-3.5 w-3.5 shrink-0 rounded-full border border-white/80" style={orbStyle(player.color)} />
              <span className="truncate">{t('turnOf', { name: currentName })}</span>
            </span>
          )}
        </div>
        <CrownIcon className="h-7 w-9 shrink-0 opacity-90" />
      </header>

      <div className="flex flex-1 flex-col items-center gap-3 px-3 pb-4 landscape:flex-row landscape:items-center landscape:justify-center">
        <div className="flex w-full items-center justify-center landscape:flex-1">
          <div className="board-wrap">
            <Board
              players={game.players}
              activeSeat={seat}
              highlight={highlight}
              theme={theme}
              onToken={(tokenId) => dispatch({ type: 'MOVE', tokenId })}
            />
          </div>
        </div>

        <aside className="flex w-full max-w-[560px] flex-col gap-3 landscape:w-72 landscape:max-w-none">
          <div className="grid grid-cols-2 gap-2">
            {game.players.map((p, i) => {
              const active = i === seat && game.phase !== 'over';
              const finishedRank = game.winners.indexOf(i);
              return (
                <div key={i} className={`seat-card ${active ? 'seat-active' : ''}`}>
                  <span className="h-5 w-5 shrink-0 rounded-full border border-white/80" style={orbStyle(p.color)} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-semibold text-amber-50">{playerLabel(p, i, t)}</div>
                    <div className="truncate text-[11px] text-amber-100/70">
                      {colorName(p.color, t)} · {t('homeCount', { n: homeCount(p) })}
                    </div>
                  </div>
                  {finishedRank >= 0 && (
                    <span className="text-xs font-bold text-amber-300">{t(RANK_KEYS[finishedRank])}</span>
                  )}
                </div>
              );
            })}
          </div>

          <div className="panel flex items-center gap-3 rounded-3xl p-3">
            <Dice value={game.dice} rolling={game.phase === 'rolling'} />
            <p className="min-h-10 flex-1 text-sm leading-snug text-amber-50" aria-live="polite">
              {status}
            </p>
            <Button
              onClick={() => dispatch({ type: 'ROLL_START' })}
              disabled={!canRoll}
              className="min-w-[7.5rem] text-base"
            >
              {t('rollDice')}
            </Button>
          </div>

          <DevCredit t={t} />
        </aside>
      </div>

      {game.phase === 'over' && (
        <div className="fade-in fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-6 backdrop-blur-sm">
          <div className="panel pop-in w-full max-w-sm rounded-3xl p-6 text-center">
            <CrownIcon className="mx-auto h-14 w-20 drop-shadow-lg" />
            <h2 className="font-display gold-text mt-2 text-3xl font-bold">
              {t('wins', { name: playerLabel(game.players[winnerSeat], winnerSeat, t) })}
            </h2>
            <h3 className="mt-5 text-xs font-semibold uppercase tracking-widest text-amber-200/85">{t('ranking')}</h3>
            <ol className="mt-3 flex flex-col gap-2 text-left">
              {game.winners.map((s, i) => (
                <li key={s} className="flex items-center gap-3 rounded-2xl bg-white/5 px-3 py-2">
                  <span className="w-12 text-sm font-bold text-amber-300">{t(RANK_KEYS[i])}</span>
                  <span className="h-4 w-4 shrink-0 rounded-full border border-white/80" style={orbStyle(game.players[s].color)} />
                  <span className="text-sm font-semibold text-amber-50">{playerLabel(game.players[s], s, t)}</span>
                </li>
              ))}
            </ol>
            <div className="mt-6 flex flex-col gap-3">
              <Button onClick={onPlayAgain} className="w-full">
                {t('playAgain')}
              </Button>
              <Button variant="ghost" onClick={onHome} className="w-full">
                {t('home')}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
