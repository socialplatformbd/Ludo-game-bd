import { useMemo } from 'react';
import {
  BASE_SPOTS,
  COLORS,
  HOME_LANE,
  SAFE_TRACK,
  START,
  TRACK,
  cellOf,
  type Cell,
  type Color,
  type Player,
} from '../game/logic';
import { PALETTE, type ThemeDef } from '../game/themes';

// Five-point star polygon (unit size, centred on 0,0).
const STAR = Array.from({ length: 10 }, (_, i) => {
  const r = i % 2 === 0 ? 1 : 0.42;
  const a = -Math.PI / 2 + (i * Math.PI) / 5;
  return `${(r * Math.cos(a)).toFixed(3)},${(r * Math.sin(a)).toFixed(3)}`;
}).join(' ');

const YARDS: Record<Color, Cell> = {
  red: [0, 9],
  green: [0, 0],
  yellow: [9, 0],
  blue: [9, 9],
};

const START_COLOR: Record<number, Color> = {
  [START.red]: 'red',
  [START.green]: 'green',
  [START.yellow]: 'yellow',
  [START.blue]: 'blue',
};

// Spreads tokens that share one cell so they stay visible.
function stackOffset(index: number, count: number): [number, number] {
  if (count <= 1) return [0, 0];
  const radius = count === 2 ? 0.2 : 0.25;
  const angle = -Math.PI / 2 + (index * 2 * Math.PI) / count;
  return [radius * Math.cos(angle), radius * Math.sin(angle)];
}

interface Props {
  players: Player[];
  activeSeat: number;
  highlight: number[];
  theme: ThemeDef;
  onToken: (tokenId: number) => void;
}

interface PlacedToken {
  key: string;
  seat: number;
  tokenId: number;
  color: Color;
  x: number;
  y: number;
  progress: number;
  off: [number, number];
}

export function Board({ players, activeSeat, highlight, theme, onToken }: Props) {
  const placed = useMemo<PlacedToken[]>(() => {
    const items: Omit<PlacedToken, 'off'>[] = [];
    players.forEach((p, seat) =>
      p.tokens.forEach((t) => {
        const [x, y] = cellOf(p.color, t.progress, t.id);
        items.push({ key: `${seat}-${t.id}`, seat, tokenId: t.id, color: p.color, x, y, progress: t.progress });
      })
    );
    const groups = new Map<string, Omit<PlacedToken, 'off'>[]>();
    items.forEach((it) => {
      if (it.progress === 0) return; // home tokens already have their own spot
      const k = `${it.x},${it.y}`;
      const list = groups.get(k) ?? [];
      list.push(it);
      groups.set(k, list);
    });
    const offsets = new Map<string, [number, number]>();
    groups.forEach((list) =>
      list.forEach((it, i) => offsets.set(it.key, stackOffset(i, list.length)))
    );
    return items.map((it) => ({ ...it, off: offsets.get(it.key) ?? [0, 0] }));
  }, [players]);

  // Active player's tokens are drawn last so they sit on top.
  const ordered = [...placed].sort(
    (a, b) => Number(a.seat === activeSeat) - Number(b.seat === activeSeat)
  );

  const frame = theme.frame;

  return (
    <svg viewBox="-0.5 -0.5 16 16" role="img" aria-label="Ludo board" className="block h-full w-full">
      <defs>
        <radialGradient id="boardBg" cx="50%" cy="40%" r="75%">
          <stop offset="0" stopColor={theme.bgInner} />
          <stop offset="1" stopColor={theme.bgOuter} />
        </radialGradient>
        <linearGradient id="frameGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={frame[0]} />
          <stop offset="0.5" stopColor={frame[1]} />
          <stop offset="1" stopColor={frame[2]} />
        </linearGradient>
        <pattern id="boardDots" width="0.6" height="0.6" patternUnits="userSpaceOnUse">
          <circle cx="0.3" cy="0.3" r="0.04" fill={frame[0]} opacity="0.45" />
        </pattern>
        <radialGradient id="starGold" cx="40%" cy="35%" r="70%">
          <stop offset="0" stopColor="#fff8d0" />
          <stop offset="1" stopColor="#d4a017" />
        </radialGradient>
        {COLORS.map((c) => (
          <radialGradient key={c} id={`tok-${c}`} cx="35%" cy="30%" r="75%">
            <stop offset="0" stopColor={PALETTE[c].hi} />
            <stop offset="0.55" stopColor={PALETTE[c].mid} />
            <stop offset="1" stopColor={PALETTE[c].lo} />
          </radialGradient>
        ))}
        <filter id="tokShadow" x="-60%" y="-60%" width="220%" height="220%">
          <feDropShadow dx="0" dy="0.07" stdDeviation="0.06" floodColor="#000000" floodOpacity="0.5" />
        </filter>
      </defs>

      {/* Outer frame: royal blue with gold border */}
      <rect x={-0.35} y={-0.35} width={15.7} height={15.7} rx={0.6} fill="url(#boardBg)" />
      <rect x={-0.35} y={-0.35} width={15.7} height={15.7} rx={0.6} fill="url(#boardDots)" />
      <rect x={-0.35} y={-0.35} width={15.7} height={15.7} rx={0.6} fill="none" stroke="url(#frameGrad)" strokeWidth={0.16} />
      {[
        [-0.18, -0.18],
        [15.18, -0.18],
        [-0.18, 15.18],
        [15.18, 15.18],
      ].map(([cx, cy], i) => (
        <circle key={i} cx={cx} cy={cy} r={0.13} fill="url(#starGold)" stroke="#7a4d00" strokeWidth={0.03} />
      ))}

      {/* Home yards */}
      {COLORS.map((c) => {
        const [x, y] = YARDS[c];
        const pal = PALETTE[c];
        return (
          <g key={`yard-${c}`}>
            <rect x={x} y={y} width={6} height={6} rx={0.5} fill={pal.main} stroke="url(#frameGrad)" strokeWidth={0.07} />
            <rect x={x + 0.5} y={y + 0.5} width={5} height={5} rx={0.45} fill={pal.light} stroke={theme.cellStroke} strokeWidth={0.04} />
            {BASE_SPOTS[c].map(([bx, by], i) => (
              <g key={i}>
                <circle cx={bx + 0.5} cy={by + 0.5} r={0.46} fill={pal.dark} opacity={0.22} />
                <circle cx={bx + 0.5} cy={by + 0.5} r={0.4} fill="none" stroke={pal.main} strokeWidth={0.05} opacity={0.7} />
              </g>
            ))}
          </g>
        );
      })}

      {/* Shared track */}
      {TRACK.map(([x, y], i) => {
        const startColor = START_COLOR[i];
        return (
          <rect
            key={`t${i}`}
            x={x}
            y={y}
            width={1}
            height={1}
            fill={startColor ? PALETTE[startColor].main : theme.cell}
            stroke={theme.cellStroke}
            strokeWidth={0.035}
          />
        );
      })}

      {/* Private home lanes */}
      {COLORS.map((c) =>
        HOME_LANE[c].map(([x, y], i) => (
          <rect
            key={`h${c}${i}`}
            x={x}
            y={y}
            width={1}
            height={1}
            fill={PALETTE[c].main}
            stroke={theme.cellStroke}
            strokeWidth={0.035}
          />
        ))
      )}

      {/* Safe star squares */}
      {SAFE_TRACK.map((i) => {
        const [x, y] = TRACK[i];
        const onStart = START_COLOR[i] !== undefined;
        return (
          <polygon
            key={`s${i}`}
            points={STAR}
            transform={`translate(${x + 0.5} ${y + 0.5}) scale(0.32)`}
            fill={onStart ? '#fffbe6' : 'url(#starGold)'}
            stroke="#7a4d00"
            strokeWidth={0.07}
          />
        );
      })}

      {/* Centre: four coloured triangles and a gold crown */}
      <polygon points="6,6 9,6 7.5,7.5" fill={PALETTE.yellow.main} stroke="#7a4d00" strokeWidth={0.03} />
      <polygon points="9,6 9,9 7.5,7.5" fill={PALETTE.blue.main} stroke="#7a4d00" strokeWidth={0.03} />
      <polygon points="9,9 6,9 7.5,7.5" fill={PALETTE.red.main} stroke="#7a4d00" strokeWidth={0.03} />
      <polygon points="6,9 6,6 7.5,7.5" fill={PALETTE.green.main} stroke="#7a4d00" strokeWidth={0.03} />
      <g transform="translate(7.5 7.5) scale(0.082)" aria-hidden="true">
        <path
          d="M-9 4 L-10.5 -5 L-4.5 0.5 L0 -7 L4.5 0.5 L10.5 -5 L9 4 Z"
          fill="url(#frameGrad)"
          stroke="#5c3a00"
          strokeWidth={0.9}
          strokeLinejoin="round"
        />
        <rect x={-9} y={5} width={18} height={3} rx={1} fill="url(#frameGrad)" stroke="#5c3a00" strokeWidth={0.9} />
        <circle cx={0} cy={-7.6} r={1.2} fill="#fff7c2" />
        <circle cx={-10.5} cy={-5.6} r={1} fill="#fff7c2" />
        <circle cx={10.5} cy={-5.6} r={1} fill="#fff7c2" />
      </g>

      {/* Tokens */}
      {ordered.map((it) => {
        const isHint = it.seat === activeSeat && highlight.includes(it.tokenId);
        const [dx, dy] = it.off;
        return (
          <g
            key={it.key}
            onClick={isHint ? () => onToken(it.tokenId) : undefined}
            role={isHint ? 'button' : undefined}
            aria-label={isHint ? `Move ${it.color} token ${it.tokenId + 1}` : undefined}
            className={isHint ? 'cursor-pointer' : undefined}
            style={{
              transform: `translate(${it.x + 0.5 + dx}px, ${it.y + 0.5 + dy}px)`,
              transition: 'transform 170ms ease-out',
            }}
          >
            <circle r={0.52} fill="transparent" />
            {isHint && <circle r={0.48} fill="none" stroke="#ffe27a" strokeWidth={0.08} className="token-hint" />}
            <circle r={0.36} fill={`url(#tok-${it.color})`} stroke="#fffbea" strokeWidth={0.045} filter="url(#tokShadow)" />
            <ellipse cx={-0.1} cy={-0.14} rx={0.13} ry={0.075} fill="#ffffff" opacity={0.75} transform="rotate(-25)" />
          </g>
        );
      })}
    </svg>
  );
}
