import { Card, CrownIcon, Page, TELEGRAM_URL } from './ui';
import type { T } from '../game/i18n';

interface Props {
  t: T;
  onBack: () => void;
}

export function AboutScreen({ t, onBack }: Props) {
  return (
    <Page title={t('aboutTitle')} t={t} onBack={onBack}>
      <Card className="flex flex-col items-center gap-4 py-8 text-center">
        <div className="crown-badge">
          <CrownIcon className="h-12 w-16 drop-shadow-lg" />
        </div>
        <h2 className="font-display gold-text text-3xl font-black">{t('appName')}</h2>
        <p className="text-xs text-amber-100/70">{t('version')}</p>
        <p className="text-sm leading-relaxed text-amber-50/90">{t('aboutBody')}</p>
      </Card>

      <Card className="flex flex-col items-center gap-3 text-center">
        <p className="text-xs font-semibold uppercase tracking-widest text-amber-200/85">{t('developer')}</p>
        <p className="font-display text-2xl font-bold text-amber-100">Made by Mohammad Rakib</p>
        <a
          href={TELEGRAM_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-gold mt-2 inline-flex min-h-12 w-full items-center justify-center rounded-2xl px-5 py-3 text-base font-bold no-underline"
        >
          {t('openChannel')}
        </a>
        <p className="break-all text-xs text-amber-100/70">
          {t('telegram')}: {TELEGRAM_URL}
        </p>
      </Card>
    </Page>
  );
}
