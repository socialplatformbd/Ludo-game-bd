// Pause lengths (milliseconds) for the automatic turn engine.
export type Speed = 'normal' | 'fast' | 'turbo';

export interface Timing {
  cpuRoll: number; // computer waits before rolling
  rolling: number; // dice tumble time
  cpuMove: number; // computer waits before moving
  pass: number; // pause before an impossible turn passes
  step: number; // time per cell a token walks
  auto: number; // pause before a single possible move is played for you
}

export const TIMING: Record<Speed, Timing> = {
  normal: { cpuRoll: 500, rolling: 520, cpuMove: 500, pass: 800, step: 140, auto: 220 },
  fast: { cpuRoll: 350, rolling: 420, cpuMove: 380, pass: 550, step: 105, auto: 160 },
  turbo: { cpuRoll: 120, rolling: 200, cpuMove: 150, pass: 260, step: 55, auto: 80 },
};

export const SPEEDS: Speed[] = ['normal', 'fast', 'turbo'];
