// Local-only persistence (localStorage). Nothing leaves the device.
// Saved data is validated before use, so a corrupted value can never crash the app.

import { COLORS, DEFAULT_RULES, HOME, type GameState, type Level, type Rules } from './logic';
import type { Lang } from './i18n';
import { THEMES, type ThemeId } from './themes';
import { SPEEDS, type Speed } from './speed';
import { TOKEN_STYLE_IDS, type TokenStyle } from './tokens';

export interface Settings {
  sound: boolean;
  music: boolean;
  vibration: boolean;
  theme: ThemeId;
  lang: Lang;
  rules: Rules;
  speed: Speed;
  tokenStyle: TokenStyle;
  autoMove: boolean; // play the move for you when only one is possible
  profileName: string; // remembered name for player 1
  profileAvatar: string;
}

export const DEFAULT_SETTINGS: Settings = {
  sound: true,
  music: false,
  vibration: true,
  theme: 'royal',
  lang: 'en',
  rules: DEFAULT_RULES,
  speed: 'fast',
  tokenStyle: 'pawn',
  autoMove: true,
  profileName: '',
  profileAvatar: '😎',
};

const SETTINGS_KEY = 'royal-ludo:settings:v1';
const GAME_KEY = 'royal-ludo:game:v1';

function readRaw(key: string): string | null {
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

function writeRaw(key: string, value: string | null) {
  try {
    if (value === null) window.localStorage.removeItem(key);
    else window.localStorage.setItem(key, value);
  } catch {
    // Storage full or blocked. The game still works, it just will not persist.
  }
}

export function loadSettings(): Settings {
  const raw = readRaw(SETTINGS_KEY);
  if (!raw) return DEFAULT_SETTINGS;
  try {
    const data = JSON.parse(raw) as Partial<Settings>;
    const rules = { ...DEFAULT_RULES };
    const savedRules = (data.rules ?? {}) as Partial<Record<keyof Rules, unknown>>;
    (Object.keys(DEFAULT_RULES) as (keyof Rules)[]).forEach((k) => {
      if (typeof savedRules[k] === 'boolean') rules[k] = savedRules[k] as boolean;
    });
    return {
      sound: typeof data.sound === 'boolean' ? data.sound : DEFAULT_SETTINGS.sound,
      music: typeof data.music === 'boolean' ? data.music : DEFAULT_SETTINGS.music,
      vibration: typeof data.vibration === 'boolean' ? data.vibration : DEFAULT_SETTINGS.vibration,
      theme:
        typeof data.theme === 'string' && Object.prototype.hasOwnProperty.call(THEMES, data.theme)
          ? (data.theme as ThemeId)
          : DEFAULT_SETTINGS.theme,
      speed: SPEEDS.includes(data.speed as Speed) ? (data.speed as Speed) : DEFAULT_SETTINGS.speed,
      tokenStyle: TOKEN_STYLE_IDS.includes(data.tokenStyle as TokenStyle)
        ? (data.tokenStyle as TokenStyle)
        : DEFAULT_SETTINGS.tokenStyle,
      autoMove: typeof data.autoMove === 'boolean' ? data.autoMove : DEFAULT_SETTINGS.autoMove,
      profileName: typeof data.profileName === 'string' ? data.profileName.slice(0, 12) : '',
      profileAvatar:
        typeof data.profileAvatar === 'string' && data.profileAvatar.length > 0 && data.profileAvatar.length <= 8
          ? data.profileAvatar
          : DEFAULT_SETTINGS.profileAvatar,
      lang: data.lang === 'en' || data.lang === 'bn' ? data.lang : DEFAULT_SETTINGS.lang,
      rules,
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: Settings) {
  writeRaw(SETTINGS_KEY, JSON.stringify(settings));
}

function isValidGame(data: unknown): data is GameState {
  if (!data || typeof data !== 'object') return false;
  const g = data as Partial<GameState>;
  if (!Array.isArray(g.players) || g.players.length < 2 || g.players.length > 4) return false;
  if (!Number.isInteger(g.current) || g.current! < 0 || g.current! >= g.players.length) return false;
  if (!['roll', 'rolling', 'move', 'moving', 'over'].includes(String(g.phase))) return false;
  if (g.phase === 'moving' && (!g.moving || !Number.isInteger(g.moving.seat) || !Number.isInteger(g.moving.tokenId) || !Number.isInteger(g.moving.steps) || g.moving.seat < 0 || g.moving.seat >= g.players.length || g.moving.tokenId < 0 || g.moving.tokenId > 3 || g.moving.steps < 1 || g.moving.steps > 57)) return false;
  // A 'move' phase without a dice value could never continue (the game would freeze).
  if (g.phase === 'move' && (g.dice === null || g.dice === undefined)) return false;
  if (!Array.isArray(g.winners) || !g.winners.every((w) => Number.isInteger(w) && w >= 0 && w < g.players!.length)) return false;
  if (g.dice !== null && g.dice !== undefined && (!Number.isInteger(g.dice) || g.dice < 1 || g.dice > 6)) return false;
  const playersOk = g.players.every(
    (p) =>
      p !== null &&
      typeof p === 'object' &&
      COLORS.includes(p.color) &&
      typeof p.cpu === 'boolean' &&
      Array.isArray(p.tokens) &&
      p.tokens.length === 4 &&
      p.tokens.every(
        (t, i) => t.id === i && Number.isInteger(t.progress) && t.progress >= 0 && t.progress <= HOME
      )
  );
  return playersOk;
}

export function loadGame(): GameState | null {
  const raw = readRaw(GAME_KEY);
  if (!raw) return null;
  try {
    const data: unknown = JSON.parse(raw);
    if (!isValidGame(data)) return null;
    const level: Level = data.level === 'easy' || data.level === 'hard' ? data.level : 'normal';
    const rawStats = Array.isArray(data.stats) ? data.stats : [];
    const num = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) && v >= 0 ? Math.floor(v) : 0);
    return {
      ...data,
      level,
      stats: data.players.map((_, i) => ({
        sixes: num(rawStats[i]?.sixes),
        captures: num(rawStats[i]?.captures),
      })),
      players: data.players.map((p) => {
        const { name, avatar, ...rest } = p;
        return {
          ...rest,
          ...(typeof name === 'string' && name.trim() ? { name: name.trim().slice(0, 12) } : {}),
          ...(typeof avatar === 'string' && avatar.length > 0 && avatar.length <= 8 ? { avatar } : {}),
        };
      }),
      rules: { ...DEFAULT_RULES, ...data.rules },
      evt: data.evt ?? { kind: 'start', n: 0 },
      dice: typeof data.dice === 'number' ? data.dice : null,
      sixes: typeof data.sixes === 'number' ? data.sixes : 0,
    };
  } catch {
    return null;
  }
}

export function saveGame(game: GameState | null) {
  writeRaw(GAME_KEY, game ? JSON.stringify(game) : null);
}

// ---------- Lifetime stats (this device only) ----------

export interface Stats {
  games: number;
  wins: number;
  captures: number;
  sixes: number;
}

export const EMPTY_STATS: Stats = { games: 0, wins: 0, captures: 0, sixes: 0 };

const STATS_KEY = 'royal-ludo:stats:v1';

export function loadStats(): Stats {
  const raw = readRaw(STATS_KEY);
  if (!raw) return EMPTY_STATS;
  try {
    const d = JSON.parse(raw) as Partial<Record<keyof Stats, unknown>>;
    const num = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) && v >= 0 ? Math.floor(v) : 0);
    return { games: num(d.games), wins: num(d.wins), captures: num(d.captures), sixes: num(d.sixes) };
  } catch {
    return EMPTY_STATS;
  }
}

export function saveStats(stats: Stats) {
  writeRaw(STATS_KEY, JSON.stringify(stats));
}
