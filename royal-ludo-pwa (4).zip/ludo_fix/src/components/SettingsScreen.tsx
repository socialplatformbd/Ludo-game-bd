import { useEffect, useState } from 'react';
import { Button, Card, Page, SettingRow, Toggle } from './ui';
import type { Lang, T } from '../game/i18n';
import type { Settings } from '../game/storage';
import { THEMES, type ThemeId } from '../game/themes';
import { TOKEN_STYLES } from '../game/tokens';
import { TokenDefs, TokenPreview } from './TokenArt';
import { SPEEDS, type Speed } from '../game/speed';

interface Props {
  t: T;
  settings: Settings;
  hasGame: boolean;
  onChange: (patch: Partial<Settings>) => void;
  onReset: () => void;
  onRules: () => void;
  onAbout: () => void;
  onBack: () => void;
}

const THEME_KEYS = {
  royal: 'themeRoyal',
  emerald: 'themeEmerald',
  midnight: 'themeMidnight',
  neon: 'themeNeon',
  wood: 'themeWood',
  marble: 'themeMarble',
  crimson: 'themeCrimson',
  ocean: 'themeOcean',
  galaxy: 'themeGalaxy',
  sunset: 'themeSunset',
  classic: 'themeClassic',
  snow: 'themeSnow',
  slate: 'themeSlate',
  rose: 'themeRose',
  ice: 'themeIce',
  lava: 'themeLava',
  carbon: 'themeCarbon',
} as const;

const TIERS = ['normal', 'premium'] as const;

const SPEED_KEYS: Record<Speed, 'speedNormal' | 'speedFast' | 'speedTurbo'> = {
  normal: 'speedNormal',
  fast: 'speedFast',
  turbo: 'speedTurbo',
};

export function SettingsScreen({ t, settings, hasGame, onChange, onReset, onRules, onAbout, onBack }: Props) {
  const [confirming, setConfirming] = useState(false);

  // The reset button needs a second tap; it cancels itself after a few seconds.
  useEffect(() => {
    if (!confirming) return;
    const id = window.setTimeout(() => setConfirming(false), 4000);
    return () => window.clearTimeout(id);
  }, [confirming]);

  const languages: { id: Lang; label: string }[] = [
    { id: 'en', label: t('english') },
    { id: 'bn', label: t('bangla') },
  ];

  return (
    <Page title={t('settings')} t={t} onBack={onBack}>
      <Card>
        <p className="mb-1 text-xs font-semibold uppercase tracking-widest text-amber-200/85">{t('audio')}</p>
        <SettingRow label={t('sound')}>
          <Toggle label={t('sound')} checked={settings.sound} onChange={(v) => onChange({ sound: v })} />
        </SettingRow>
        <SettingRow label={t('music')}>
          <Toggle label={t('music')} checked={settings.music} onChange={(v) => onChange({ music: v })} />
        </SettingRow>
        <SettingRow label={t('vibration')}>
          <Toggle label={t('vibration')} checked={settings.vibration} onChange={(v) => onChange({ vibration: v })} />
        </SettingRow>
      </Card>

      <Card>
        <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-amber-200/85">{t('appearance')}</p>
        <p className="mb-2 text-[15px] text-amber-50">{t('boardTheme')}</p>
        {TIERS.map((tier) => (
          <div key={tier} className="mb-3">
            <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-amber-300/90">
              {tier === 'normal' ? t('tierNormal') : `✦ ${t('tierPremium')}`}
            </p>
            <div className="grid grid-cols-3 gap-2">
              {(Object.keys(THEMES) as ThemeId[])
                .filter((id) => THEMES[id].tier === tier)
                .map((id) => {
                  const selected = settings.theme === id;
                  return (
                    <button
                      key={id}
                      type="button"
                      aria-pressed={selected}
                      onClick={() => onChange({ theme: id })}
                      className={`flex flex-col items-center gap-2 rounded-2xl p-2 text-center transition ${
                        selected ? 'ring-2 ring-amber-300 bg-amber-300/10' : 'bg-white/5'
                      }`}
                    >
                      <span className="h-12 w-full rounded-xl border border-amber-200/50" style={{ background: THEMES[id].swatch }} />
                      <span className="text-[11px] font-semibold leading-tight text-amber-50">{t(THEME_KEYS[id])}</span>
                    </button>
                  );
                })}
            </div>
          </div>
        ))}
      </Card>

      <Card>
        <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-amber-200/85">{t('tokenStyle')}</p>
        <svg width="0" height="0" className="absolute" aria-hidden="true">
          <defs>
            <TokenDefs />
          </defs>
        </svg>
        {TIERS.map((tier) => (
          <div key={tier} className="mb-3">
            <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-amber-300/90">
              {tier === 'normal' ? t('tierNormal') : `✦ ${t('tierPremium')}`}
            </p>
            <div className="grid grid-cols-3 gap-2">
              {TOKEN_STYLES.filter((s) => s.tier === tier).map((s) => {
                const selected = settings.tokenStyle === s.id;
                return (
                  <button
                    key={s.id}
                    type="button"
                    aria-pressed={selected}
                    onClick={() => onChange({ tokenStyle: s.id })}
                    className={`flex flex-col items-center gap-1 rounded-2xl p-2 text-center transition ${
                      selected ? 'ring-2 ring-amber-300 bg-amber-300/10' : 'bg-white/5'
                    }`}
                  >
                    <span className="w-full rounded-xl bg-[#fcf3dc] py-1">
                      <TokenPreview kind={s.id} />
                    </span>
                    <span className="text-[11px] font-semibold leading-tight text-amber-50">{t(s.name)}</span>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </Card>

      <Card>
        <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-amber-200/85">{t('speed')}</p>
        <div className="grid grid-cols-3 gap-2">
          {SPEEDS.map((s) => (
            <button
              key={s}
              type="button"
              aria-pressed={settings.speed === s}
              onClick={() => onChange({ speed: s })}
              className={`min-h-12 rounded-2xl text-base font-bold transition ${
                settings.speed === s ? 'btn-gold' : 'btn-ghost'
              }`}
            >
              {t(SPEED_KEYS[s])}
            </button>
          ))}
        </div>
        <SettingRow label={t('autoMove')}>
          <Toggle label={t('autoMove')} checked={settings.autoMove} onChange={(v) => onChange({ autoMove: v })} />
        </SettingRow>
      </Card>

      <Card>
        <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-amber-200/85">{t('language')}</p>
        <div className="grid grid-cols-2 gap-2">
          {languages.map((l) => (
            <button
              key={l.id}
              type="button"
              aria-pressed={settings.lang === l.id}
              onClick={() => onChange({ lang: l.id })}
              className={`min-h-12 rounded-2xl text-base font-bold transition ${
                settings.lang === l.id ? 'btn-gold' : 'btn-ghost'
              }`}
            >
              {l.label}
            </button>
          ))}
        </div>
      </Card>

      <Card>
        <p className="mb-2 text-xs font-semibold uppercase tracking-widest text-amber-200/85">{t('gameSection')}</p>
        <Button variant="ghost" className="w-full" onClick={onRules}>
          {t('rules')}
        </Button>
        <div className="mt-3">
          <Button
            variant="danger"
            className="w-full"
            disabled={!hasGame}
            onClick={() => {
              if (!confirming) {
                setConfirming(true);
                return;
              }
              setConfirming(false);
              onReset();
            }}
          >
            {confirming ? t('confirmReset') : t('resetGame')}
          </Button>
        </div>
        <p className="mt-2 text-center text-xs text-amber-100/65">{t('resetHint')}</p>
      </Card>

      <Card>
        <p className="mb-2 text-xs font-semibold uppercase tracking-widest text-amber-200/85">{t('developer')}</p>
        <Button variant="ghost" className="w-full" onClick={onAbout}>
          {t('about')}
        </Button>
      </Card>
    </Page>
  );
}
