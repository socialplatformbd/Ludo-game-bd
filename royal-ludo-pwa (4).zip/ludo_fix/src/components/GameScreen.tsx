import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Board } from './Board';
import { Dice } from './Dice';
import { Button, CrownIcon, DevCredit } from './ui';
import { homeCount, legalTokenIds, type Action, type Color, type GameState, type Player } from '../game/logic';
import { colorName, type Key, type T } from '../game/i18n';
import { PALETTE, type ThemeDef } from '../game/themes';
import { TIMING, type Speed } from '../game/speed';
import type { TokenStyle } from '../game/tokens';

const RANK_KEYS: Key[] = ['rank1', 'rank2', 'rank3', 'rank4'];

export function playerLabel(player: Player, seat: number, t: T): string {
  const custom = player.name?.trim();
  if (custom) return custom;
  return player.cpu ? t('cpuName', { n: seat + 1 }) : t('playerName', { n: seat + 1 });
}

function avatarOf(player: Player): string {
  return player.avatar ?? (player.cpu ? '🤖' : '🙂');
}

interface Props {
  t: T;
  game: GameState;
  theme: ThemeDef;
  speed: Speed;
  tokenStyle: TokenStyle;
  dispatch: (action: Action) => void;
  onHome: () => void;
  onPlayAgain: () => void;
}

function orbStyle(color: keyof typeof PALETTE) {
  const p = PALETTE[color];
  return {
    background: `radial-gradient(circle at 35% 30%, ${p.hi}, ${p.mid} 60%, ${p.lo})`,
  };
}

function useLandscape(): boolean {
  const query = '(orientation: landscape)';
  const [land, setLand] = useState(
    () => typeof window !== 'undefined' && typeof window.matchMedia === 'function' && window.matchMedia(query).matches
  );
  useEffect(() => {
    if (typeof window.matchMedia !== 'function') return;
    const mq = window.matchMedia(query);
    const update = () => setLand(mq.matches);
    update();
    mq.addEventListener('change', update);
    return () => mq.removeEventListener('change', update);
  }, []);
  return land;
}

interface PanelProps {
  t: T;
  player: Player;
  seat: number;
  active: boolean;
  rank: number;
  dice: number | null;
  rolling: boolean;
  canRoll: boolean;
  onRoll: () => void;
}

// One card per player: name, progress, and the player's own dice + Roll button.
function PlayerPanel({ t, player, seat, active, rank, dice, rolling, canRoll, onRoll }: PanelProps) {
  return (
    <div className={`seat-card ${active ? 'seat-active' : ''}`}>
      <div className="flex items-center gap-2">
        <span
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-white/80 text-base"
          style={orbStyle(player.color)}
          aria-hidden="true"
        >
          {avatarOf(player)}
        </span>
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-semibold text-amber-50">{playerLabel(player, seat, t)}</div>
          <div className="truncate text-[11px] text-amber-100/70">
            {colorName(player.color, t)} · {t('homeCount', { n: homeCount(player) })}
          </div>
        </div>
        {rank >= 0 && <span className="text-xs font-bold text-amber-300">{t(RANK_KEYS[rank])}</span>}
      </div>
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={onRoll}
          disabled={!canRoll}
          aria-label={t('rollDice')}
          className={`dice-btn ${canRoll ? 'dice-ready' : ''}`}
        >
          <Dice small value={active ? dice : null} rolling={active && rolling} />
        </button>
        <Button onClick={onRoll} disabled={!canRoll} className="flex-1 px-2 py-2 text-sm">
          {t('rollDice')}
        </Button>
      </div>
    </div>
  );
}

const CONFETTI_COLORS = ['#f5c542', '#e53e5a', '#22a35a', '#2f6fe0', '#fff3b5', '#ff8a3d'];

function Confetti() {
  const pieces = useMemo(
    () =>
      Array.from({ length: 44 }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 1.2,
        duration: 2.6 + Math.random() * 2,
        size: 6 + Math.random() * 7,
        color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
      })),
    []
  );
  return (
    <div aria-hidden="true">
      {pieces.map((p) => (
        <span
          key={p.id}
          className="confetti-piece"
          style={{
            left: `${p.left}%`,
            width: p.size,
            height: p.size * 1.6,
            background: p.color,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.duration}s`,
          }}
        />
      ))}
    </div>
  );
}

export function GameScreen({ t, game, theme, speed, tokenStyle, dispatch, onHome, onPlayAgain }: Props) {
  const seat = game.current;
  const player = game.players[seat];
  const isHuman = !player.cpu;
  const legal =
    game.phase === 'move' && game.dice !== null ? legalTokenIds(player, game.dice, game.rules) : [];
  const canRoll = game.phase === 'roll' && isHuman;
  const highlight = isHuman ? legal : [];
  const currentName = playerLabel(player, seat, t);

  let status: string;
  if (game.evt.kind === 'triple' && game.phase === 'roll') {
    status = t('triple');
  } else if (game.phase === 'roll') {
    status = isHuman ? t('yourTurn') : t('cpuPlaying', { name: currentName });
  } else if (game.phase === 'rolling') {
    status = t('rolling');
  } else if (game.phase === 'move') {
    if (legal.length === 0) status = t('noMoves');
    else status = isHuman ? t('tapToken') : t('cpuPlaying', { name: currentName });
  } else if (game.phase === 'moving') {
    status = t('moving');
  } else {
    status = '';
  }

  const winnerSeat = game.winners[0] ?? 0;

  const landscape = useLandscape();
  const stepMs = TIMING[speed].step;
  const onToken = useCallback((tokenId: number) => dispatch({ type: 'MOVE', tokenId }), [dispatch]);

  // Shake the board when a token is captured.
  const [shake, setShake] = useState(false);
  const lastEvt = useRef(game.evt.n);
  useEffect(() => {
    if (game.evt.n === lastEvt.current) return;
    lastEvt.current = game.evt.n;
    if (game.evt.kind !== 'capture') return;
    setShake(true);
    const id = window.setTimeout(() => setShake(false), 380);
    return () => window.clearTimeout(id);
  }, [game.evt.n, game.evt.kind]);

  // Panels sit next to their own yard: green/yellow above the board, red/blue below it.
  const TOP: Color[] = ['green', 'yellow'];
  const BOTTOM: Color[] = ['red', 'blue'];
  const ALL: Color[] = ['red', 'green', 'yellow', 'blue'];

  const renderPanel = (color: Color) => {
    const i = game.players.findIndex((p) => p.color === color);
    if (i < 0) return <div key={color} aria-hidden="true" />;
    const p = game.players[i];
    const active = i === seat && game.phase !== 'over';
    return (
      <PlayerPanel
        key={color}
        t={t}
        player={p}
        seat={i}
        active={active}
        rank={game.winners.indexOf(i)}
        dice={game.dice}
        rolling={game.phase === 'rolling'}
        canRoll={active && canRoll}
        onRoll={() => dispatch({ type: 'ROLL_START' })}
      />
    );
  };

  const statusLine = (
    <p className="min-h-6 text-center text-sm font-medium leading-snug text-amber-50" aria-live="polite">
      {status}
    </p>
  );

  return (
    <div className="flex min-h-dvh flex-col">
      <header className="flex items-center gap-3 px-4 pb-2 pt-[calc(env(safe-area-inset-top)+10px)]">
        <button type="button" onClick={onHome} className="icon-btn" aria-label={t('home')}>
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M3 11l9-7 9 7" />
            <path d="M5 10v10h14V10" />
          </svg>
        </button>
        <div className="flex min-w-0 flex-1 items-center justify-center">
          {game.phase !== 'over' && (
            <span className="turn-chip">
              <span className="h-3.5 w-3.5 shrink-0 rounded-full border border-white/80" style={orbStyle(player.color)} />
              <span className="truncate">{t('turnOf', { name: currentName })}</span>
            </span>
          )}
        </div>
        <CrownIcon className="h-7 w-9 shrink-0 opacity-90" />
      </header>

      <div className="flex flex-1 flex-col items-center gap-2 px-3 pb-4 landscape:flex-row landscape:items-center landscape:justify-center landscape:gap-4">
        <div className="flex w-full max-w-[560px] flex-col items-center gap-2 landscape:flex-1">
          {!landscape && <div className="grid w-full grid-cols-2 gap-2">{TOP.map(renderPanel)}</div>}
          <div className={`board-wrap ${shake ? 'board-shake' : ''}`}>
            <Board
              players={game.players}
              activeSeat={seat}
              highlight={highlight}
              theme={theme}
              stepMs={stepMs}
              tokenStyle={tokenStyle}
              onToken={onToken}
            />
          </div>
          {!landscape && (
            <>
              {statusLine}
              <div className="grid w-full grid-cols-2 gap-2">{BOTTOM.map(renderPanel)}</div>
              <DevCredit t={t} />
            </>
          )}
        </div>

        {landscape && (
          <aside className="flex w-72 shrink-0 flex-col gap-2">
            <div className="grid grid-cols-2 gap-2">{ALL.map(renderPanel)}</div>
            {statusLine}
            <DevCredit t={t} />
          </aside>
        )}
      </div>

      {game.phase === 'over' && (
        <div className="fade-in fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-6 backdrop-blur-sm">
          <Confetti />
          <div className="panel pop-in relative z-[56] w-full max-w-sm rounded-3xl p-6 text-center">
            <CrownIcon className="mx-auto h-14 w-20 drop-shadow-lg" />
            <h2 className="font-display gold-text mt-2 text-3xl font-bold">
              {t('wins', { name: playerLabel(game.players[winnerSeat], winnerSeat, t) })}
            </h2>
            <h3 className="mt-5 text-xs font-semibold uppercase tracking-widest text-amber-200/85">{t('ranking')}</h3>
            <ol className="mt-3 flex flex-col gap-2 text-left">
              {game.winners.map((s, i) => (
                <li key={s} className="flex items-center gap-3 rounded-2xl bg-white/5 px-3 py-2">
                  <span className="w-10 shrink-0 text-sm font-bold text-amber-300">{t(RANK_KEYS[i])}</span>
                  <span
                    className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-white/80 text-sm"
                    style={orbStyle(game.players[s].color)}
                    aria-hidden="true"
                  >
                    {avatarOf(game.players[s])}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-semibold text-amber-50">{playerLabel(game.players[s], s, t)}</span>
                    <span className="block text-[11px] text-amber-100/65">
                      {t('statCaptures')} {game.stats[s]?.captures ?? 0} · {t('statSixes')} {game.stats[s]?.sixes ?? 0}
                    </span>
                  </span>
                </li>
              ))}
            </ol>
            <div className="mt-6 flex flex-col gap-3">
              <Button onClick={onPlayAgain} className="w-full">
                {t('playAgain')}
              </Button>
              <Button variant="ghost" onClick={onHome} className="w-full">
                {t('home')}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
